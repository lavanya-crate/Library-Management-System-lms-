// import React, { useState } from "react";
// import {
//   Box,
//   Button,
//   TextField,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Pagination,
//   Stack,
//   IconButton,
//   InputAdornment,
//   DialogContent,
//   Divider,
//   DialogTitle,
//   DialogActions,
//   Dialog,
// } from "@mui/material";
// import SearchIcon from "@mui/icons-material/Search";
// import image from "../images/category.jpg";


// const initialCategories = [
//   { id: 1, name: "Science", description: "Books related to Science" },
//   { id: 2, name: "Mathematics", description: "Books related to Math" },
//   { id: 3, name: "History", description: "Books about History" },
//   { id: 4, name: "Technology", description: "Books on Technology" },
//   { id: 5, name: "Literature", description: "Literary works" },
//   { id: 6, name: "Art", description: "Books about Art and Design" },
//   { id: 7, name: "Physics", description: "Physics textbooks and resources" },
//   { id: 8, name: "Chemistry", description: "Chemistry books" },
//   { id: 9, name: "Biology", description: "Biological sciences" },
//   { id: 10, name: "Philosophy", description: "Philosophical works" },
//   { id: 11, name: "Psychology", description: "Books on Psychology" },
//   { id: 12, name: "Geography", description: "Books on Geography" },
//   { id: 13, name: "Economics", description: "Economic studies" },
//   { id: 14, name: "Politics", description: "Political science books" },
//   { id: 15, name: "Sociology", description: "Books on Sociology" },
//   { id: 16, name: "Languages", description: "Language learning books" },
//   { id: 17, name: "Music", description: "Books on Music theory and history" },
//   { id: 18, name: "Education", description: "Educational resources" },
//   { id: 19, name: "Sports", description: "Books about sports" },
//   { id: 20, name: "Travel", description: "Travel guides and books" },
// ];

// export const CategoriesSection = () => {
//   const [categories, setCategories] = useState(initialCategories);
//   const [newCategory, setNewCategory] = useState({ name: "", description: "" });
//   const [showForm, setShowForm] = useState(false);
//   const [searchTerm, setSearchTerm] = useState("");
//   const [currentPage, setCurrentPage] = useState(1);
//   const itemsPerPage = 5;
//   const [openDialog, setOpenDialog] = useState(false);

//   const handleOpen = () => {
//     setOpenDialog(true);
//   };

//   const handleClose = () => {
//     setOpenDialog(false);
//     setNewCategory({ name: "", description: "" });
//   };


//   const handleAddCategory = () => {
//     if (!newCategory.name.trim()) return alert("Category name is required");

//     const newId = categories.length > 0 ? categories[categories.length - 1].id + 1 : 1;

//     setCategories([
//       ...categories,
//       {
//         id: newId,
//         name: newCategory.name.trim(),
//         description: newCategory.description.trim(),
//       },
//     ]);

//   };

//   const handleDelete = (id) => {
//     setCategories(categories.filter((category) => category.id !== id));
//   };

 
//   const handleSearch = (e) => {
//     setSearchTerm(e.target.value);
//     setCurrentPage(1); 
//   };

//   const filteredCategories = categories.filter((category) =>
//     category.name.toLowerCase().includes(searchTerm.toLowerCase())
//   );

//   const totalPages = Math.ceil(filteredCategories.length / itemsPerPage);

//   const paginatedCategories = filteredCategories.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   return (
//     <Box sx={{ p: 3, ml: 50, mr: 20, mt: 10 }}>
//       {/* Search and Add Button */}
//       <Box
//         sx={{
//           flex: 1,
//           backgroundColor: "#fff",
//           display: "flex",
//           justifyContent: "space-between",
//           alignItems: "center",
//           p: 2,
//         }}
//       >
//         <TextField
//           placeholder="Search by Categories"
//           variant="outlined"
//           value={searchTerm}
//           onChange={handleSearch}
//           sx={{ mb: 2, width: 400, mt: 2, ml: -2 }}
//           InputProps={{
//             startAdornment: (
//               <InputAdornment position="start">
//                 <IconButton edge="start">
//                   <SearchIcon />
//                 </IconButton>
//               </InputAdornment>
//             ),
//           }}
//         />

//         {!showForm && (
//           <Button variant="contained" onClick={handleOpen} sx={{ mb: 2, backgroundColor: "#6e2ca3", }}>
//             Add Category
//           </Button>
//         )}
//       </Box>

//       {/* Add Form */}

//       <Dialog open={openDialog} onClose={handleClose} maxWidth="md" fullWidth>
//         <DialogTitle>Add New Category</DialogTitle>
//         <Divider />
//         <DialogContent>
//           <Box sx={{ display: "flex", alignItems: "center", gap: 4 }}>


//             {/* Left side image */}
//             <Box sx={{ flex: 1 }}>
//               <img
//                 src={image}
//                 alt="Category"
//                 style={{
//                   width: 420,
//                   height: 400,
//                   objectFit: "cover",
//                   borderRadius: 8,
//                 }}
//               />
//             </Box>


//             {/* Right side form */}
//             <Box sx={{ flex: 1, display: "flex", flexDirection: "column", gap: 2 }}>
//               <TextField
//                 label="Category Name"
//                 value={newCategory.name}
//                 onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
//                 variant="outlined"
//                 required
//               />
//               <TextField
//                 label="Description"
//                 value={newCategory.description}
//                 onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })}
//                 variant="outlined"
//                 multiline
//                 rows={3}
//               />
//             </Box>
//           </Box>
//         </DialogContent>

//         <DialogActions>
//           <Button onClick={handleClose} color="secondary" variant="outlined">
//             Cancel
//           </Button>
//           <Button sx={{ backgroundColor: "#6e2ca3" }}
//             onClick={() => {
//               handleAddCategory();
//               handleClose();
//             }}
//             variant="contained"
//           >
//             Save
//           </Button>
//         </DialogActions>
//       </Dialog>


//       {/* Table */}
//       <TableContainer component={Paper}>
//         <Table>
//           <TableHead>
//             <TableRow sx={{ bgcolor: "#6e2ca3", color: "white" }}>
//               <TableCell sx={{ color: "white" }}>Category Name</TableCell>
//               <TableCell sx={{ color: "white" }}>Description</TableCell>
//               <TableCell sx={{ color: "white" }}>Actions</TableCell>
//             </TableRow>
//           </TableHead>

//           <TableBody>
//             {paginatedCategories.map(({ id, name, description }) => (
//               <TableRow key={id}>
//                 <TableCell>{name}</TableCell>
//                 <TableCell>{description}</TableCell>
//                 <TableCell>
//                   <Button variant="contained" color="error" onClick={() => handleDelete(id)}>
//                     Delete
//                   </Button>
//                 </TableCell>
//               </TableRow>
//             ))}

//             {paginatedCategories.length === 0 && (
//               <TableRow>
//                 <TableCell colSpan={3} align="center">
//                   No categories found.
//                 </TableCell>
//               </TableRow>
//             )}
//           </TableBody>
//         </Table>
//       </TableContainer>

//       {/* Pagination */}
//       {totalPages > 1 && (
//         <Stack direction="row" justifyContent="center" sx={{ mt: 2 }}>
//           <Pagination
//             count={totalPages}
//             page={currentPage}
//             onChange={(e, value) => setCurrentPage(value)}

//           />
//         </Stack>
//       )}
//     </Box>
//   );
// };


import React, { useState } from "react";
import {
  Box,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Pagination,
  Stack,
  IconButton,
  InputAdornment,
  Divider,
  DialogTitle,
  DialogActions,
  Dialog,
  Typography,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import image from "../images/category.jpg";
import img from "../images/category1.avif";
import { SidebarSection } from "./SidebarSection";

const initialCategories = [
  { id: 1, name: "Science", description: "Books about science topics", totalBooks: 120, status: "Active" },
  { id: 2, name: "Literature", description: "Literary books collection", totalBooks: 85, status: "Inactive" },
  { id: 3, name: "History", description: "Historical books and documents", totalBooks: 50, status: "Active" },
  { id: 4, name: "Art", description: "Books about art and artists", totalBooks: 70, status: "Active" },
  { id: 5, name: "Mathematics", description: "Mathematical theories and problems", totalBooks: 95, status: "Inactive" },
  { id: 6, name: "Philosophy", description: "Philosophical works and essays", totalBooks: 40, status: "Active" },
  { id: 7, name: "Technology", description: "Technology and computing books", totalBooks: 110, status: "Active" },
  { id: 8, name: "Travel", description: "Travel guides and journals", totalBooks: 30, status: "Inactive" },
  { id: 9, name: "Cooking", description: "Cookbooks and recipes", totalBooks: 65, status: "Active" },
  { id: 10, name: "Health", description: "Health and wellness books", totalBooks: 80, status: "Active" },
  { id: 11, name: "Sports", description: "Sports history and techniques", totalBooks: 55, status: "Inactive" },
  { id: 12, name: "Business", description: "Business and finance books", totalBooks: 90, status: "Active" },
  { id: 13, name: "Biography", description: "Biographies and memoirs", totalBooks: 45, status: "Active" },
  { id: 14, name: "Children", description: "Books for children and young readers", totalBooks: 130, status: "Inactive" },
  { id: 15, name: "Fantasy", description: "Fantasy novels and stories", totalBooks: 150, status: "Active" },
  { id: 16, name: "Mystery", description: "Mystery and thriller books", totalBooks: 85, status: "Active" },
  { id: 17, name: "Romance", description: "Romantic novels", totalBooks: 100, status: "Inactive" },
  { id: 18, name: "Science Fiction", description: "Sci-fi books and stories", totalBooks: 120, status: "Active" },
  { id: 19, name: "Self-help", description: "Self-improvement books", totalBooks: 75, status: "Active" },
  { id: 20, name: "Religion", description: "Religious texts and discussions", totalBooks: 60, status: "Inactive" },
];

export const CategoriesSection = () => {
  const [categories, setCategories] = useState(initialCategories);
  const [newCategory, setNewCategory] = useState({ name: "", description: "", totalBooks: "", status: "" });
  const [openDialog, setOpenDialog] = useState();
  const [openEditDialog, setOpenEditDialog] = useState();
  const [editingCategory, setEditingCategory] = useState();
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  const handleOpen = () => setOpenDialog(true);
  const handleClose = () => {
    setOpenDialog(false);
    setNewCategory({ name: "", description: "", totalBooks: "", status: "" });
  };

  const handleEditOpen = (category) => {
    setEditingCategory(category);
    setOpenEditDialog(true);
  };

  const handleEditClose = () => {
    setOpenEditDialog(false);
    setEditingCategory();
  };

  const handleAddCategory = () => {
    if (!newCategory.name.trim()) return alert("Category name is required");
    if (!newCategory.status.trim()) return alert("Status is required");

    const newId = categories.length > 0 ? categories[categories.length - 1].id + 1 : 1;

    setCategories([
      ...categories,
      {
        id: newId,
        name: newCategory.name.trim(),
        description: newCategory.description.trim(),
        totalBooks: parseInt(newCategory.totalBooks),
        status: newCategory.status.trim(),
      },
    ]);
    handleClose();
  };

  const handleUpdateCategory = () => {
    if (!editingCategory.name.trim()) return alert("Category name is required");
    if (!editingCategory.status.trim()) return alert("Status is required");

    setCategories((prev) =>
      prev.map((cat) =>
        cat.id === editingCategory.id
          ? {
              ...cat,
              name: editingCategory.name.trim(),
              description: editingCategory.description.trim(),
              totalBooks: parseInt(editingCategory.totalBooks),
              status: editingCategory.status.trim(),
            }
          : cat
      )
    );
    handleEditClose();
  };

  const handleDelete = (id) => {
    setCategories(categories.filter((cat) => cat.id !== id));
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  };

  const filteredCategories = categories.filter((cat) =>
    cat.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(filteredCategories.length / itemsPerPage);
  const paginatedCategories = filteredCategories.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <>
    <SidebarSection />
    <Box sx={{ p: 3, ml: 50, mr: 20, mt: 10 }}>
      <Typography variant="h4" sx={{ mb: 4 }} fontWeight="bold">Categories</Typography>

      {/* Search + Add */}
      <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
        <TextField
          placeholder="Search by Categories"
          value={searchTerm}
          onChange={handleSearch}
          variant="outlined"
          sx={{ width: 400 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
        <Button variant="contained" sx={{ backgroundColor: "#6e2ca3" }} onClick={handleOpen}>
          Add Category
        </Button>
      </Box>

      {/* Table */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow sx={{ bgcolor: "#6e2ca3" }}>
              <TableCell sx={{ color: "white" }}>Category Name</TableCell>
              <TableCell sx={{ color: "white" }}>Description</TableCell>
              <TableCell sx={{ color: "white" }}>Total Books</TableCell>
              <TableCell sx={{ color: "white" }}>Status</TableCell>
              <TableCell sx={{ color: "white" }}>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {paginatedCategories.map((cat) => (
              <TableRow key={cat.id}>
                <TableCell>{cat.name}</TableCell>
                <TableCell>{cat.description}</TableCell>
                <TableCell>{cat.totalBooks}</TableCell>
                <TableCell>{cat.status}</TableCell>
                <TableCell>
                  <IconButton color="primary" onClick={() => handleEditOpen(cat)}>
                    <EditIcon />
                  </IconButton>
                  <IconButton color="error" onClick={() => handleDelete(cat.id)}>
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
            {paginatedCategories.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} align="center">No categories found.</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Pagination */}
      {totalPages > 1 && (
        <Stack direction="row" justifyContent="center" sx={{ mt: 2 }}>
          <Pagination count={totalPages} page={currentPage} onChange={(e, val) => setCurrentPage(val)} />
        </Stack>
      )}

      {/* Add Category Dialog */}
      <Dialog open={openDialog} onClose={handleClose} maxWidth="md" fullWidth>
        <DialogTitle>Add New Category</DialogTitle>
        <Divider sx={{ mb: 2 }} />
        <Box sx={{ display: "flex", gap: 4, p: 3 }}>
          <Box>
            <img src={image} alt="Category" style={{ width: 420, height: 400, objectFit: "cover", borderRadius: 8 }} />
          </Box>
          <Box sx={{ flex: 1, display: "flex", flexDirection: "column", gap: 2,  mt:6 }}>
            <TextField label="Category Name" value={newCategory.name} onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })} required />
            <TextField label="Description" value={newCategory.description} onChange={(e) => setNewCategory({ ...newCategory, description: e.target.value })} multiline rows={3} />
            {/* <TextField label="Total Books" type="number" value={newCategory.totalBooks} onChange={(e) => setNewCategory({ ...newCategory, totalBooks: e.target.value })} required /> */}
            <TextField label="Status" value={newCategory.status} onChange={(e) => setNewCategory({ ...newCategory, status: e.target.value })} required placeholder="Active or Inactive" />
          </Box>
        </Box>
        <DialogActions>
          <Button onClick={handleClose} color="secondary">Cancel</Button>
          <Button onClick={handleAddCategory} variant="contained" sx={{ backgroundColor: "#6e2ca3" }}>Save</Button>
        </DialogActions>
      </Dialog>

      {/* Edit Category Dialog */}
      <Dialog open={openEditDialog} onClose={handleEditClose} maxWidth="md" fullWidth>
        <DialogTitle>Edit Category</DialogTitle>
        <Divider sx={{ mb: 2 }} />
        <Box sx={{ display: "flex", gap: 4, p: 3 }}>
          <Box>
            <img src={img} alt="Category" style={{ width: 420, height: 400, objectFit: "cover", borderRadius: 8 }} />
          </Box>
          <Box sx={{ flex: 1, display: "flex", flexDirection: "column", gap: 2, mt:6 }}>
            <TextField label="Category Name" value={editingCategory?.name || ""} onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })} required />
            <TextField label="Description" value={editingCategory?.description || ""} onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })} multiline rows={3} />
            {/* <TextField label="Total Books" type="number" value={editingCategory?.totalBooks || ""} onChange={(e) => setEditingCategory({ ...editingCategory, totalBooks: e.target.value })} required /> */}
            <TextField label="Status" value={editingCategory?.status || ""} onChange={(e) => setEditingCategory({ ...editingCategory, status: e.target.value })} required placeholder="Active or Inactive" />
          </Box>
        </Box>
        <DialogActions>
          <Button onClick={handleEditClose} color="secondary">Cancel</Button>
          <Button onClick={handleUpdateCategory} variant="contained" sx={{ backgroundColor: "#6e2ca3" }}>Update</Button>
        </DialogActions>
      </Dialog>
    </Box>
    </>
  );
};
