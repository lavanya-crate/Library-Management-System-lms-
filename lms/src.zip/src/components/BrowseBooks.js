// import React, { useState } from "react";
// import {
//   Box,
//   Card,
//   CardContent,
//   Typography,
//   Grid,
//   CardMedia,
//   Button,
//   TextField,
// } from "@mui/material";

// // Sample borrowed books data
// const initialBorrowedBooks = [
//   {
//     id: 1,
//     studentId: "STU001",
//     name: "Atomic Habits",
//     author: "James Clear",
//     image: "images/book1.webp",
//   },
//   {
//     id: 2,
//     studentId: "STU002",
//     name: "The Great Gatsby",
//     author: "F. Scott Fitzgerald",
//     image: "/images/book2.avif",
//   },
//   // Add more as needed...
// ];

// export const BrowseBooks = () => {
//   const [borrowedBooks, setBorrowedBooks] = useState(initialBorrowedBooks);
//   const [searchTerm, setSearchTerm] = useState("");

//   // Handle borrowing a new book (sample entry)
//   const handleBorrowBook = () => {
//     const newBook = {
//       id: borrowedBooks.length + 1,
//       studentId: "",
//       name: "",
//       author: "",
//       image: "",
//     };
//     setBorrowedBooks([...borrowedBooks, newBook]);
//   };

//   // Filter books based on search term
//   const filteredBooks = borrowedBooks.filter((book) =>
//     `${book.name} ${book.author}`.toLowerCase().includes(searchTerm.toLowerCase())
//   );

//   return (
//     <Box sx={{ p: 3, ml: 50, mr: 20, mt: 10 }}>
//       <Typography variant="h4" gutterBottom fontWeight="bold" mb={2}>
//         Browse Books
//       </Typography>

//       {/* Search Box */}
//       <TextField
//         label="Search by name or author"
//         variant="outlined"
//         fullWidth
//         sx={{ mb: 4 }}
//         value={searchTerm}
//         onChange={(e) => setSearchTerm(e.target.value)}
//       />

//       <Grid container spacing={2}>
//         {filteredBooks.length === 0 ? (
//           <Typography variant="body1" p={2}>
//             No books found.
//           </Typography>
//         ) : (
//           filteredBooks.map((book) => (
//             <Grid item xs={12} sm={6} md={4} key={book.id}>
//               <Card elevation={3} sx={{ width: 250, mb: 2, ml: 1 }}>
//                 <CardMedia
//                   component="img"
//                   height="200"
//                   image={book.image}
//                   alt={book.name}
//                 />
//                 <CardContent>
//                   <Typography variant="subtitle2" color="text.secondary">
//                     Student ID: {book.studentId}
//                   </Typography>
//                   <Typography variant="h6">{book.name}</Typography>
//                   <Typography variant="body2" color="text.secondary">
//                     Author: {book.author}
//                   </Typography>
//                   <Button
//                     variant="contained"
//                     color="primary"
//                     onClick={handleBorrowBook}
//                   >
//                     Borrow Book
//                   </Button>
//                 </CardContent>
//               </Card>
//             </Grid>
//           ))
//         )}
//       </Grid>
//     </Box>
//   );
// };


import React, { useState } from "react";
import {
  Box,
  Card,
  CardContent,
  Typography,
  Grid,
  CardMedia,
  Button,
  TextField,
} from "@mui/material";
import { StudentSidebar } from "./StudentSidebar";


const initialBorrowedBooks = [
  {
    id: 1,
    studentId: "STU001",
    name: "Atomic Habits",
    author: "James Clear",
    borrowDate: "2025-06-01",
    returnDate: "2025-06-08",
    // image: image,
    image: "images/book1.webp"
  },
  {
    id: 2,
    studentId: "STU002",
    name: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    borrowDate: "2025-06-02",
    returnDate: "2025-06-09",
    image: "/images/book2.avif",
  },
  {
    id: 3,
    studentId: "STU003",
    name: "Rich Dad Poor Dad",
    author: "Robert Kiyosaki",
    borrowDate: "2025-06-03",
    returnDate: "2025-06-10",
    image: "/images/book1.webp",
  },
  {
    id: 4,
    studentId: "STU004",
    name: "India het",
    author: "George Orwell",
    borrowDate: "2025-06-04",
    returnDate: "2025-06-11",
    image: "/images/book2.avif",
  },
  {
    id: 5,
    studentId: "STU005",
    name: "Deep Work",
    author: "Cal Newport",
    borrowDate: "2025-06-05",
    returnDate: "2025-06-12",
    image: "/images/book1.webp",
  },
  {
    id: 6,
    studentId: "STU006",
    name: "The Alchemist",
    author: "Paulo Coelho",
    borrowDate: "2025-06-06",
    returnDate: "2025-06-13",
    image: "/images/book2.avif",
  },
  {
    id: 7,
    studentId: "STU007",
    name: "Start With Why",
    author: "Simon Sinek",
    borrowDate: "2025-06-07",
    returnDate: "2025-06-14",
    image: "/images/book1.webp",
  },
  {
    id: 8,
    studentId: "STU008",
    name: "Clean Code",
    author: "Robert C. Martin",
    borrowDate: "2025-06-08",
    returnDate: "2025-06-15",
    image: "/images/book2.avif",
  },
  // {
  //   id: 9,
  //   studentId: "STU009",
  //   name: "To Kill a Mockingbird",
  //   author: "Harper Lee",
  //   borrowDate: "2025-06-09",
  //   returnDate: "2025-06-16",
  // },
  // {
  //   id: 10,
  //   studentId: "STU010",
  //   name: "Thinking, Fast and Slow",
  //   author: "Daniel Kahneman",
  //   borrowDate: "2025-06-10",
  //   returnDate: "2025-06-17",
  // },
];

export const BrowseBooks = () => {
  const [books, setBooks] = useState(initialBorrowedBooks);
  const [searchTerm, setSearchTerm] = useState("");

  const handleBorrowBook = (id) => {
    const updatedBooks = books.map((book) =>
      book.id === id ? { ...book, isBorrowed: true } : book
    );
    setBooks(updatedBooks);
  };


const filteredBooks = books.filter((book) =>
    `${book.name} ${book.author} ${book.category}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase())
  );

  return (
    <>
    <StudentSidebar />
    <Box sx={{ p: 3, ml: 50, mr: 20, mt: 10 }}>
      <Typography variant="h4" gutterBottom fontWeight="bold" mb={2}>
        Browse Books
      </Typography>

      {/* Search Box */}
      <TextField
        label="Search by name or author"
        variant="outlined"
        fullWidth
        sx={{ mb: 4 }}
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      <Grid container spacing={2}>
        {filteredBooks.length === 0 ? (
          <Typography variant="body1" p={2}>
            No books found.
          </Typography>
        ) : (
          filteredBooks.map((book) => (
            <Grid item xs={12} sm={6} md={4} key={book.id}>
              <Card elevation={3} sx={{ width: 258, mb: 2 }}>
                <CardMedia
                  component="img"
                  height="200"
                  image={book.image}
                  alt={book.name}
                />
                <CardContent>
                  <Typography variant="h6">{book.name}</Typography>
                  <Typography variant="body2" color="text.secondary">
                    Author: {book.author}
                  </Typography>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => handleBorrowBook(book.id)}
                    sx={{ mt: 1 }}
                  >
                   Borrow Book
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          ))
        )}
      </Grid>
    </Box>
    </>
  );
};


// import React, { useState } from "react";
// import {
//   Box,
//   Card,
//   CardContent,
//   Typography,
//   Grid,
//   CardMedia,
//   Button,
//   TextField,
// } from "@mui/material";

// const availableBooks = [
//   {
//     id: 2,
//     name: "Atomic Habits",
//     author: "James Clear",
//     category: "Self Help",
//     image: "/images/book1.webp",
//   },
//   {
//     id: 3,
//     name: "Rich Dad Poor Dad",
//     author: "Robert Kiyosaki",
//     category: "Finance",
//     image: "/images/book2.avif",
//   },
// ];

// export const BrowseBooks = ({ borrowedBooks, setBorrowedBooks }) => {
//   const [searchTerm, setSearchTerm] = useState("");

//   const handleBorrowBook = (book) => {
//     const newBook = {
//       ...book,
//       id: borrowedBooks.length + 1,
//       borrowDate: new Date().toISOString().split("T")[0],
//       limit: "14 days",
//       fine: "0",
//     };
//     setBorrowedBooks([...borrowedBooks, newBook]);
//   };

//   const filteredBooks = availableBooks.filter((book) =>
//     `${book.name} ${book.author}`.toLowerCase().includes(searchTerm.toLowerCase())
//   );

//   return (
//     <Box sx={{ p: 3, ml: 50, mr: 20, mt: 10 }}>
//       <Typography variant="h4" gutterBottom fontWeight="bold" mb={2}>
//         Browse Books
//       </Typography>

//       <TextField
//         label="Search by name or author"
//         variant="outlined"
//         fullWidth
//         sx={{ mb: 4 }}
//         value={searchTerm}
//         onChange={(e) => setSearchTerm(e.target.value)}
//       />

//       <Grid container spacing={2}>
//         {filteredBooks.length === 0 ? (
//           <Typography variant="body1" p={2}>
//             No books found.
//           </Typography>
//         ) : (
//           filteredBooks.map((book) => (
//             <Grid item xs={12} sm={6} md={4} key={book.id}>
//               <Card elevation={3} sx={{ width: 250, mb: 2, ml: 1 }}>
//                 <CardMedia
//                   component="img"
//                   height="200"
//                   image={book.image}
//                   alt={book.name}
//                 />
//                 <CardContent>
//                   <Typography variant="h6">{book.name}</Typography>
//                   <Typography variant="body2" color="text.secondary">
//                     Author: {book.author}
//                   </Typography>
//                   <Button
//                     variant="contained"
//                     color="primary"
//                     onClick={() => handleBorrowBook(book)}
//                   >
//                     Borrow Book
//                   </Button>
//                 </CardContent>
//               </Card>
//             </Grid>
//           ))
//         )}
//       </Grid>
//     </Box>
//   );
// };
