// import React, { useState } from "react";
// import {
//   Box,
//   Typography,
//   TextField,
//   Button,
//   Link,
//   Paper,
// } from "@mui/material";
// import loginImage from "../images/login-img.png";
// import registerImage from "../images/register-img.png";
// import { useNavigate } from "react-router-dom";

// export const SigninPage = () => {
//   const [isLogin, setIsLogin] = useState(true);
//   const [name, setName] = useState(""); // Only for register
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");

//   const navigate = useNavigate();
//     const handleNavigation = (path) => {
//         if (path) navigate(path);
//     };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (isLogin) {
//       // Perform login logic
//       console.log("Login with:", { email, password });
//     } else {
//       // Perform register logic
//       console.log("Register with:", { name, email, password });
//     }

//     navigate("/dashboard"); // Change path based on your app
//   };

//   const toggleMode = () => {
//     setIsLogin(!isLogin);
//     setEmail("");
//     setPassword("");
//     setName("");
//   };

//   return (
//     <Box
//       sx={{
//         minHeight: "86vh",
//         backgroundColor: "#e9e0f6",
//         display: "flex",
//         paddingLeft: 62,
//         alignItems: "center",
//         marginTop: 9,
//         paddingBottom: 5,
//       }}
//     >
//       <Paper
//         sx={{
//           display: "flex",
//           flexDirection: { xs: "column", md: "row" },
//           borderRadius: 4,
//           overflow: "hidden",
//           maxWidth: 1000,
//         }}
//       >
//         {/* Left Image */}
//         <Box
//           sx={{
//             flex: 1,
//             backgroundColor: "#fff",
//             display: "flex",
//             justifyContent: "flex-start",
//             alignItems: "center",
//             p: 2,
//           }}
//         >
//           <Box
//             component="img"
//             src={isLogin ? loginImage : registerImage}
//             alt={isLogin ? "Login illustration" : "Register illustration"}
//             sx={{
//               width: 450,
//               height: 600,
//               objectFit: "cover",
//               borderRadius: 2,
//             }}
//           />
//         </Box>

//         {/* Right Form */}
//         <Box
//           sx={{
//             p: { xs: 3, md: 5 },
//             display: "flex",
//             flexDirection: "column",
//             justifyContent: "center",
//             backgroundColor: "#fff",
//             height: 600,
//             width: 450,
//           }}
//         >
//           <Typography variant="h5" fontWeight="bold" align="center" mb={2}>
//             {isLogin ? "Login" : "Register"}
//           </Typography>

//           <form onSubmit={handleSubmit}>
//             {!isLogin && (
//               <TextField
//                 margin="normal"
//                 fullWidth
//                 label="Student Name"
//                 value={name}
//                 onChange={(e) => setName(e.target.value)}
//               />
//             )}

//             <TextField
//               margin="normal"
//               fullWidth
//               label="Email"
//               type="email"
//               value={email}
//               onChange={(e) => setEmail(e.target.value)}
//             />

//             <TextField
//               margin="normal"
//               fullWidth
//               label="Password"
//               type="password"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//             />

//             <Box
//               sx={{
//                 display: "flex",
//                 justifyContent: "space-between",
//                 alignItems: "center",
//                 width: 400,
//                 mt: 1,
//                 mb: 2,
//               }}
//             >
//               <Link href="#" variant="body2" underline="none">
//                 Forget Password?
//               </Link>
//               <Link component="button" variant="body2" onClick={() => handleNavigation('/register')}>
//                 {isLogin
//                   ? "Don't have an account? Register"
//                   : "Already have an account? Login"}
//               </Link>
//             </Box>

//             <Button
//               type="submit"
//               fullWidth
//               variant="contained"
//               sx={{
//                 backgroundColor: "#6e2ca3",
//                 color: "white",
//                 textTransform: "none",
//                 py: 1.5,
//                 fontWeight: "bold",
//                 borderRadius: 2,
//               }}
//             >
//               {isLogin ? "Login" : "Register"}
//             </Button>
//           </form>
//         </Box>
//       </Paper>
//     </Box>
//   );
// };


import React, { useState } from "react";
import {
    Box,
    Typography,
    TextField,
    Button,
    Link,
    Paper,
} from "@mui/material";
import loginImage from "../images/login-img.png";
import registerImage from "../images/register-img.png";
import { useNavigate } from "react-router-dom";

export const SigninPage = () => {
    const [isLogin, setIsLogin] = useState(true);
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        if (isLogin) {
            console.log("Login with:", { email, password });
            navigate("/");
        } 
        else {
            console.log("Register with:", { name, email, password });
            navigate("/register");
        }
    };


    const toggleMode = () => {
        setIsLogin(!isLogin);
        setEmail("");
        setPassword("");
    };

    return (
        
            <Box
                sx={{
                    minHeight: "86vh",
                    backgroundColor: "#e9e0f6",
                    display: "flex",
                    paddingLeft: 45,
                    paddingTop: 7,
                    paddingBottom: 7,
                }}
            >
                <Paper
                    sx={{
                        display: "flex",
                        flexDirection: { xs: "column", md: "row" },
                        borderRadius: 4,
                        overflow: "hidden",
                        maxWidth: 1000,
                    }}
                >
                    {/* Left Image */}
                    <Box
                        sx={{
                            flex: 1,
                            backgroundColor: "#fff",
                            display: "flex",
                            justifyContent: "flex-start",
                            alignItems: "center",
                            p: 2,
                        }}
                    >
                        <Box
                            component="img"
                            src={isLogin ? loginImage : registerImage}
                            alt={isLogin ? "Login illustration" : "Register illustration"}
                            sx={{
                                width: 450,
                                height: 600,
                                objectFit: "cover",
                                borderRadius: 2,
                            }}
                        />
                    </Box>

                    {/* Right Form */}
                    <Box
                        sx={{
                            p: { xs: 3, md: 5 },
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "center",
                            backgroundColor: "#fff",
                            height: 600,
                            width: 450,
                        }}
                    >
                        <Typography variant="h5" fontWeight="bold" align="center" mb={2}>
                          Login
                        </Typography>

                        <form onSubmit={handleSubmit}>
                            <TextField
                                margin="normal"
                                fullWidth
                                label="Email"
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                            />

                            <TextField
                                margin="normal"
                                fullWidth
                                label="Password"
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                            />

                            <Box
                                sx={{
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    width: 400,
                                    mt: 1,
                                    mb: 2,
                                }}
                            >
                                <Link href="#" variant="body2" underline="none">
                                    Forget Password?
                                </Link>
                                <Link
                                    component="button"
                                    variant="body2"
                                    onClick={toggleMode}
                                >
                                    {isLogin
                                        ? "Don't have an account? Register"
                                        : "Already have an account? Login"}
                                </Link>
                            </Box>

                            <Button
                                type="submit"
                                fullWidth
                                variant="contained"
                                sx={{
                                    backgroundColor: "#6e2ca3",
                                    color: "white",
                                    textTransform: "none",
                                    py: 1.5,
                                    fontWeight: "bold",
                                    borderRadius: 2,
                                }}
                            >
                                Login
                                {/* {isLogin ? "Login" : "Register"} */}
                            </Button>
                        </form>
                    </Box>
                </Paper>
            </Box>
  

    );
};
