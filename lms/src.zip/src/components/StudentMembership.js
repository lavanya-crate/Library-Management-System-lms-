// import React, { useState } from "react";
// import {
//   Box,
//   Button,
//   Dialog,
//   DialogActions,
//   DialogContent,
//   DialogTitle,
//   TextField,
//   Typography,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
// } from "@mui/material";

// const initialStudents = [
//   { id: 1, name: "Aarav Kumar", email: "aarav.kumar@example.com", phone: "9876543210", year: "1st", startDate: "2023-08-01" },
//   { id: 2, name: "Diya Sharma", email: "diya.sharma@example.com", phone: "9876543211", year: "2nd", startDate: "2023-08-05" },
//   { id: 3, name: "Rohan Singh", email: "rohan.singh@example.com", phone: "9876543212", year: "3rd", startDate: "2023-08-10" },
//   { id: 4, name: "Meera Joshi", email: "meera.joshi@example.com", phone: "9876543213", year: "1st", startDate: "2023-09-01" },
//   { id: 5, name: "Aryan Patel", email: "aryan.patel@example.com", phone: "9876543214", year: "4th", startDate: "2023-07-15" },
//   { id: 6, name: "Sneha Reddy", email: "sneha.reddy@example.com", phone: "9876543215", year: "2nd", startDate: "2023-09-10" },
//   { id: 7, name: "Vikram Rao", email: "vikram.rao@example.com", phone: "9876543216", year: "3rd", startDate: "2023-08-20" },
//   { id: 8, name: "Anjali Verma", email: "anjali.verma@example.com", phone: "9876543217", year: "1st", startDate: "2023-08-25" },
//   { id: 9, name: "Karan Mehta", email: "karan.mehta@example.com", phone: "9876543218", year: "2nd", startDate: "2023-07-30" },
//   { id: 10, name: "Pooja Iyer", email: "pooja.iyer@example.com", phone: "9876543219", year: "3rd", startDate: "2023-09-05" },
//   { id: 11, name: "Ritika Jain", email: "ritika.jain@example.com", phone: "9876543220", year: "1st", startDate: "2023-09-08" },
//   { id: 12, name: "Dev Sharma", email: "dev.sharma@example.com", phone: "9876543221", year: "4th", startDate: "2023-07-18" },
//   { id: 13, name: "Tanya Gupta", email: "tanya.gupta@example.com", phone: "9876543222", year: "3rd", startDate: "2023-07-25" },
//   { id: 14, name: "Sahil Kapoor", email: "sahil.kapoor@example.com", phone: "9876543223", year: "2nd", startDate: "2023-08-03" },
//   { id: 15, name: "Isha Nair", email: "isha.nair@example.com", phone: "9876543224", year: "1st", startDate: "2023-09-12" },
//   { id: 16, name: "Arjun Das", email: "arjun.das@example.com", phone: "9876543225", year: "4th", startDate: "2023-07-05" },
//   { id: 17, name: "Nisha Paul", email: "nisha.paul@example.com", phone: "9876543226", year: "3rd", startDate: "2023-08-18" },
//   { id: 18, name: "Rajiv Roy", email: "rajiv.roy@example.com", phone: "9876543227", year: "2nd", startDate: "2023-08-28" },
//   { id: 19, name: "Swati Singh", email: "swati.singh@example.com", phone: "9876543228", year: "1st", startDate: "2023-09-15" },
//   { id: 20, name: "Nikhil Bansal", email: "nikhil.bansal@example.com", phone: "9876543229", year: "4th", startDate: "2023-07-10" },
// ];

// export const StudentMembership = () => {
//   const [students, setStudents] = useState(initialStudents);
//   const [open, setOpen] = useState(false);
//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     year: "",
//     startDate: "",
//   });

//   const handleOpen = () => setOpen(true);
//   const handleClose = () => {
//     setFormData({ name: "", email: "", phone: "", year: "", startDate: "" });
//     setOpen(false);
//   };

//   const handleChange = (e) =>
//     setFormData({ ...formData, [e.target.name]: e.target.value });

//   const handleAddStudent = () => {
//     const newStudent = {
//       id: students.length + 1,
//       ...formData,
//     };
//     setStudents([...students, newStudent]);
//     handleClose();
//   };

//   return (
//     <Box p={3}>
//       <Typography variant="h4" gutterBottom>
//         Membership (Students)
//       </Typography>

//       <Button variant="contained" color="primary" onClick={handleOpen}>
//         Add New Student Membership
//       </Button>

//       <TableContainer component={Paper} sx={{ marginTop: 3 }}>
//         <Table>
//           <TableHead>
//             <TableRow>
//               <TableCell>Student ID</TableCell>
//               <TableCell>Name</TableCell>
//               <TableCell>Email</TableCell>
//               <TableCell>Phone Number</TableCell>
//               <TableCell>Year of Study</TableCell>
//               <TableCell>Membership Start Date</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {students.map((student) => (
//               <TableRow key={student.id}>
//                 <TableCell>{student.id}</TableCell>
//                 <TableCell>{student.name}</TableCell>
//                 <TableCell>{student.email}</TableCell>
//                 <TableCell>{student.phone}</TableCell>
//                 <TableCell>{student.year}</TableCell>
//                 <TableCell>{student.startDate}</TableCell>
//               </TableRow>
//             ))}
//           </TableBody>
//         </Table>
//       </TableContainer>

//       <Dialog open={open} onClose={handleClose}>
//         <DialogTitle>Add New Student Membership</DialogTitle>
//         <DialogContent>
//           <TextField
//             label="Name"
//             name="name"
//             value={formData.name}
//             onChange={handleChange}
//             fullWidth
//             margin="dense"
//           />
//           <TextField
//             label="Email"
//             name="email"
//             value={formData.email}
//             onChange={handleChange}
//             fullWidth
//             margin="dense"
//           />
//           <TextField
//             label="Phone"
//             name="phone"
//             value={formData.phone}
//             onChange={handleChange}
//             fullWidth
//             margin="dense"
//           />
//           <TextField
//             label="Year of Study"
//             name="year"
//             value={formData.year}
//             onChange={handleChange}
//             fullWidth
//             margin="dense"
//           />
//           <TextField
//             label="Membership Start Date"
//             name="startDate"
//             type="date"
//             value={formData.startDate}
//             onChange={handleChange}
//             fullWidth
//             margin="dense"
//             InputLabelProps={{ shrink: true }}
//           />
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={handleClose} color="secondary">
//             Cancel
//           </Button>
//           <Button onClick={handleAddStudent} variant="contained" color="primary">
//             Add
//           </Button>
//         </DialogActions>
//       </Dialog>
//     </Box>
//   );
// };



// import React, { useState } from "react";
// import {
//   Box,
//   Button,
//   Typography,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   DialogActions,
//   TextField,
//   IconButton,
//   Grid,
// } from "@mui/material";
// import EditIcon from "@mui/icons-material/Edit";
// import DeleteIcon from "@mui/icons-material/Delete";
// import img from "../images/category1.avif"; // Adjust path to your image

// const initialStudents = Array.from({ length: 20 }, (_, i) => ({
//   id: i + 1,
//   name: `Student ${i + 1}`,
//   email: `student${i + 1}@example.com`,
//   phone: `98765${String(10000 + i).slice(-5)}`,
//   year: `${(i % 4) + 1} Year`,
//   startDate: `2023-0${(i % 9) + 1}-01`,
// }));

// export const StudentMembership= () => {
//   const [students, setStudents] = useState(initialStudents);
//   const [isAddOpen, setAddOpen] = useState(false);
//   const [isEditOpen, setEditOpen] = useState(false);
//   const [selectedStudent, setSelectedStudent] = useState(null);
//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     year: "",
//     startDate: "",
//   });

//   const handleInputChange = (e) =>
//     setFormData({ ...formData, [e.target.name]: e.target.value });

//   const handleAddOpen = () => {
//     setFormData({ name: "", email: "", phone: "", year: "", startDate: "" });
//     setAddOpen(true);
//   };

//   const handleAddStudent = () => {
//     setStudents([
//       ...students,
//       { ...formData, id: students.length + 1 },
//     ]);
//     setAddOpen(false);
//   };

//   const handleEditOpen = (student) => {
//     setSelectedStudent(student);
//     setFormData(student);
//     setEditOpen(true);
//   };

//   const handleEditStudent = () => {
//     setStudents((prev) =>
//       prev.map((s) => (s.id === selectedStudent.id ? formData : s))
//     );
//     setEditOpen(false);
//   };

//   const handleDelete = (id) =>
//     setStudents((prev) => prev.filter((s) => s.id !== id));

//   return (
//     <Box p={3}>
//       <Typography variant="h4" gutterBottom>
//         Student Membership
//       </Typography>

//       <Button variant="contained" onClick={handleAddOpen}>
//         Add New Student Membership
//       </Button>

//       <TableContainer component={Paper} sx={{ mt: 3 }}>
//         <Table>
//           <TableHead>
//             <TableRow>
//               <TableCell>ID</TableCell>
//               <TableCell>Name</TableCell>
//               <TableCell>Email</TableCell>
//               <TableCell>Phone</TableCell>
//               <TableCell>Year</TableCell>
//               <TableCell>Start Date</TableCell>
//               <TableCell align="center">Actions</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {students.map((s) => (
//               <TableRow key={s.id}>
//                 <TableCell>{s.id}</TableCell>
//                 <TableCell>{s.name}</TableCell>
//                 <TableCell>{s.email}</TableCell>
//                 <TableCell>{s.phone}</TableCell>
//                 <TableCell>{s.year}</TableCell>
//                 <TableCell>{s.startDate}</TableCell>
//                 <TableCell align="center">
//                   <IconButton color="primary" onClick={() => handleEditOpen(s)}>
//                     <EditIcon />
//                   </IconButton>
//                   <IconButton color="error" onClick={() => handleDelete(s.id)}>
//                     <DeleteIcon />
//                   </IconButton>
//                 </TableCell>
//               </TableRow>
//             ))}
//           </TableBody>
//         </Table>
//       </TableContainer>

//       {/* Add Dialog */}
//       <Dialog open={isAddOpen} onClose={() => setAddOpen(false)} maxWidth="md">
//         <DialogTitle>Add Student</DialogTitle>
//         <DialogContent>
//           <Grid container spacing={2}>
//             <Grid item xs={12} md={5}>
//               <Box
//                 component="img"
//                 src={img}
//                 alt="student"
//                 sx={{ width: "100%", height: "100%", objectFit: "cover" }}
//               />
//             </Grid>
//             <Grid item xs={12} md={7}>
//               <TextField
//                 fullWidth
//                 name="name"
//                 label="Name"
//                 margin="dense"
//                 value={formData.name}
//                 onChange={handleInputChange}
//               />
//               <TextField
//                 fullWidth
//                 name="email"
//                 label="Email"
//                 margin="dense"
//                 value={formData.email}
//                 onChange={handleInputChange}
//               />
//               <TextField
//                 fullWidth
//                 name="phone"
//                 label="Phone"
//                 margin="dense"
//                 value={formData.phone}
//                 onChange={handleInputChange}
//               />
//               <TextField
//                 fullWidth
//                 name="year"
//                 label="Year of Study"
//                 margin="dense"
//                 value={formData.year}
//                 onChange={handleInputChange}
//               />
//               <TextField
//                 fullWidth
//                 name="startDate"
//                 type="date"
//                 label="Start Date"
//                 margin="dense"
//                 InputLabelProps={{ shrink: true }}
//                 value={formData.startDate}
//                 onChange={handleInputChange}
//               />
//             </Grid>
//           </Grid>
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={() => setAddOpen(false)}>Cancel</Button>
//           <Button variant="contained" onClick={handleAddStudent}>
//             Add
//           </Button>
//         </DialogActions>
//       </Dialog>

//       {/* Edit Dialog */}
//       <Dialog open={isEditOpen} onClose={() => setEditOpen(false)}>
//         <DialogTitle>Edit Student</DialogTitle>
//         <DialogContent>
//           <TextField
//             fullWidth
//             name="name"
//             label="Name"
//             margin="dense"
//             value={formData.name}
//             onChange={handleInputChange}
//           />
//           <TextField
//             fullWidth
//             name="email"
//             label="Email"
//             margin="dense"
//             value={formData.email}
//             onChange={handleInputChange}
//           />
//           <TextField
//             fullWidth
//             name="phone"
//             label="Phone"
//             margin="dense"
//             value={formData.phone}
//             onChange={handleInputChange}
//           />
//           <TextField
//             fullWidth
//             name="year"
//             label="Year of Study"
//             margin="dense"
//             value={formData.year}
//             onChange={handleInputChange}
//           />
//           <TextField
//             fullWidth
//             name="startDate"
//             type="date"
//             label="Start Date"
//             margin="dense"
//             InputLabelProps={{ shrink: true }}
//             value={formData.startDate}
//             onChange={handleInputChange}
//           />
//         </DialogContent>
//         <DialogActions>
//           <Button onClick={() => setEditOpen(false)}>Cancel</Button>
//           <Button variant="contained" onClick={handleEditStudent}>
//             Update
//           </Button>
//         </DialogActions>
//       </Dialog>
//     </Box>
//   );
// };



import React, { useState } from "react";
import {
  Box,
  Button,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  Grid,
  Pagination,
  InputAdornment,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import SearchIcon from "@mui/icons-material/Search";
import img from "../images/category1.avif";
import { SidebarSection } from "./SidebarSection";

const initialStudents = [
  { id: 1, name: "Aarav Kumar", email: "aarav.kumar@example.com", phone: "9876543210", year: "1st", startDate: "2023-08-01" },
  { id: 2, name: "Diya Sharma", email: "diya.sharma@example.com", phone: "9876543211", year: "2nd", startDate: "2023-08-05" },
  { id: 3, name: "Rohan Singh", email: "rohan.singh@example.com", phone: "9876543212", year: "3rd", startDate: "2023-08-10" },
  { id: 4, name: "Meera Joshi", email: "meera.joshi@example.com", phone: "9876543213", year: "1st", startDate: "2023-09-01" },
  { id: 5, name: "Aryan Patel", email: "aryan.patel@example.com", phone: "9876543214", year: "4th", startDate: "2023-07-15" },
  { id: 6, name: "Sneha Reddy", email: "sneha.reddy@example.com", phone: "9876543215", year: "2nd", startDate: "2023-09-10" },
  { id: 7, name: "Vikram Rao", email: "vikram.rao@example.com", phone: "9876543216", year: "3rd", startDate: "2023-08-20" },
  { id: 8, name: "Anjali Verma", email: "anjali.verma@example.com", phone: "9876543217", year: "1st", startDate: "2023-08-25" },
  { id: 9, name: "Karan Mehta", email: "karan.mehta@example.com", phone: "9876543218", year: "2nd", startDate: "2023-07-30" },
  { id: 10, name: "Pooja Iyer", email: "pooja.iyer@example.com", phone: "9876543219", year: "3rd", startDate: "2023-09-05" },
  { id: 11, name: "Ritika Jain", email: "ritika.jain@example.com", phone: "9876543220", year: "1st", startDate: "2023-09-08" },
  { id: 12, name: "Dev Sharma", email: "dev.sharma@example.com", phone: "9876543221", year: "4th", startDate: "2023-07-18" },
  { id: 13, name: "Tanya Gupta", email: "tanya.gupta@example.com", phone: "9876543222", year: "3rd", startDate: "2023-07-25" },
  { id: 14, name: "Sahil Kapoor", email: "sahil.kapoor@example.com", phone: "9876543223", year: "2nd", startDate: "2023-08-03" },
  { id: 15, name: "Isha Nair", email: "isha.nair@example.com", phone: "9876543224", year: "1st", startDate: "2023-09-12" },
  { id: 16, name: "Arjun Das", email: "arjun.das@example.com", phone: "9876543225", year: "4th", startDate: "2023-07-05" },
  { id: 17, name: "Nisha Paul", email: "nisha.paul@example.com", phone: "9876543226", year: "3rd", startDate: "2023-08-18" },
  { id: 18, name: "Rajiv Roy", email: "rajiv.roy@example.com", phone: "9876543227", year: "2nd", startDate: "2023-08-28" },
  { id: 19, name: "Swati Singh", email: "swati.singh@example.com", phone: "9876543228", year: "1st", startDate: "2023-09-15" },
  { id: 20, name: "Nikhil Bansal", email: "nikhil.bansal@example.com", phone: "9876543229", year: "4th", startDate: "2023-07-10" },
];


export const StudentMembership = () => {
  const [students, setStudents] = useState(initialStudents);
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddOpen, setAddOpen] = useState(false);
  const [isEditOpen, setEditOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    year: "",
    startDate: "",
  });

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const studentsPerPage = 5;

  const handleInputChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleAddOpen = () => {
    setFormData({ name: "", email: "", phone: "", year: "", startDate: "" });
    setAddOpen(true);
  };

  const handleAddStudent = () => {
    setStudents([...students, { ...formData, id: students.length + 1 }]);
    setAddOpen(false);
  };

  const handleEditOpen = (student) => {
    setSelectedStudent(student);
    setFormData(student);
    setEditOpen(true);
  };

  const handleEditStudent = () => {
    setStudents((prev) =>
      prev.map((s) => (s.id === selectedStudent.id ? formData : s))
    );
    setEditOpen(false);
  };

  const handleDelete = (id) =>
    setStudents((prev) => prev.filter((s) => s.id !== id));

  const filteredStudents = students.filter((s) =>
    s.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const indexOfLastStudent = currentPage * studentsPerPage;
  const indexOfFirstStudent = indexOfLastStudent - studentsPerPage;
  const currentStudents = filteredStudents.slice(indexOfFirstStudent, indexOfLastStudent);
  const totalPages = Math.ceil(filteredStudents.length / studentsPerPage);

  return (
    <>
    <SidebarSection />
    <Box sx={{ p: 3, ml: 50, mr: 20, mt: 10 }}>
      <Typography variant="h4" gutterBottom fontWeight="bold" mb={4}>
        Student Membership
      </Typography>

      <Box display="flex" justifyContent="space-between" mb={4}>
        <TextField
          placeholder="Search by name"
          variant="outlined"
          size="small"
          value={searchTerm}
          sx={{ width: 400 }}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setCurrentPage(1);
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
        <Button variant="contained" onClick={handleAddOpen} sx={{ backgroundColor: "#6e2ca3" }}>
          Add New Student Membership
        </Button>
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead sx={{ bgcolor: "#6e2ca3" }}>
            <TableRow>
              <TableCell sx={{ color: "white" }}>ID</TableCell>
              <TableCell sx={{ color: "white" }}>Name</TableCell>
              <TableCell sx={{ color: "white" }}>Email</TableCell>
              <TableCell sx={{ color: "white" }}>Phone</TableCell>
              <TableCell sx={{ color: "white" }}>Year</TableCell>
              <TableCell sx={{ color: "white" }}>Membership Start Date</TableCell>
              <TableCell sx={{ color: "white" }} align="center">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {currentStudents.map((s) => (
              <TableRow key={s.id}>
                <TableCell>{s.id}</TableCell>
                <TableCell>{s.name}</TableCell>
                <TableCell>{s.email}</TableCell>
                <TableCell>{s.phone}</TableCell>
                <TableCell>{s.year}</TableCell>
                <TableCell>{s.startDate}</TableCell>
                <TableCell align="center">
                  <IconButton color="primary" onClick={() => handleEditOpen(s)}>
                    <EditIcon />
                  </IconButton>
                  <IconButton color="error" onClick={() => handleDelete(s.id)}>
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Pagination */}
      <Box display="flex" justifyContent="center" mt={2}>
        <Pagination
          count={totalPages}
          page={currentPage}
          onChange={(_, page) => setCurrentPage(page)}

        />
      </Box>

      {/* Add Dialog */}
      <Dialog open={isAddOpen} onClose={() => setAddOpen(false)} maxWidth="md" fullWidth>
        <DialogTitle>Add Student</DialogTitle>
        <DialogContent>
          <Grid container spacing={2}>
            <Grid item xs={12} md={5}>
              <Box>
                <img src={img} alt="book" style={{ width: 420, height: 400, objectFit: "cover", borderRadius: 8 }} />
              </Box>
            </Grid>
            <Grid item xs={12} md={7} sx={{ flex: 1, display: "flex", flexDirection: "column", gap: 2 }}>
              <TextField fullWidth name="name" label="Name" margin="dense" value={formData.name} onChange={handleInputChange} />
              <TextField fullWidth name="email" label="Email" margin="dense" value={formData.email} onChange={handleInputChange} />
              <TextField fullWidth name="phone" label="Phone" margin="dense" value={formData.phone} onChange={handleInputChange} />
              <TextField fullWidth name="year" label="Year of Study" margin="dense" value={formData.year} onChange={handleInputChange} />
              <TextField fullWidth name="startDate" type="date" label="Start Date" margin="dense" InputLabelProps={{ shrink: true }} value={formData.startDate} onChange={handleInputChange} />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setAddOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleAddStudent}>Add</Button>
        </DialogActions>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditOpen} onClose={() => setEditOpen(false)}  maxWidth="md" fullWidth>
        <DialogTitle>Edit Student</DialogTitle>
        <DialogContent>
           <Grid container spacing={2}>
            <Grid item xs={12} md={5}>
              <Box>
                <img src={img} alt="book" style={{ width: 420, height: 400, objectFit: "cover", borderRadius: 8 }} />
              </Box>
            </Grid>
            <Grid item xs={12} md={7} sx={{ flex: 1, display: "flex", flexDirection: "column", gap: 2 }}>
          <TextField fullWidth name="name" label="Name" margin="dense" value={formData.name} onChange={handleInputChange} />
          <TextField fullWidth name="email" label="Email" margin="dense" value={formData.email} onChange={handleInputChange} />
          <TextField fullWidth name="phone" label="Phone" margin="dense" value={formData.phone} onChange={handleInputChange} />
          <TextField fullWidth name="year" label="Year of Study" margin="dense" value={formData.year} onChange={handleInputChange} />
          <TextField fullWidth name="startDate" type="date" label="Start Date" margin="dense" InputLabelProps={{ shrink: true }} value={formData.startDate} onChange={handleInputChange} />
             </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleEditStudent}>Update</Button>
        </DialogActions>
      </Dialog>
    </Box>
    </>
  );
};
