// import React, { useState } from "react";
// import {
//   Box,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Typography,
// } from "@mui/material";

// // Initial borrowed books data
// const initialBorrowedBooks = [
//   { id: 1, name: "The Great Gatsby", author: "F. Scott Fitzgerald", category: "Fiction", borrowDate: "2023-08-01", limit: "18 days", fine: "0" },
//   { id: 2, name: "Atomic Habits", author: "James Clear", category: "Self Help", borrowDate: "2023-08-05", limit: "10 days", fine: "0" },
//   { id: 3, name: "1984", author: "George Orwell", category: "Fiction", borrowDate: "2023-08-10", limit: "12 days", fine: "0" },
//   { id: 4, name: "Rich Dad Poor Dad", author: "Robert Kiyosaki", category: "Finance", borrowDate: "2023-09-01", limit: "20 days", fine: "0" },
//   { id: 5, name: "Clean Code", author: "Robert C. Martin", category: "Programming", borrowDate: "2023-07-15", limit: "15 days", fine: "0" },
//   { id: 6, name: "Deep Work", author: "Cal Newport", category: "Self Help", borrowDate: "2023-09-10", limit: "10 days", fine: "0" },
// ];

// export const BorrowBook = () => {
//   const [borrowedBooks, setBorrowedBooks] = useState(initialBorrowedBooks);

//   // Optional: get all categories
//   const categories = [...new Set(initialBorrowedBooks.map(book => book.category))];

//   return (
//     <Box sx={{ p: 3, ml: 50, mr: 20, mt: 10 }}>
//       <Typography variant="h4" gutterBottom fontWeight="bold" mb={4}>Borrow Book</Typography>

//       <TableContainer component={Paper}>
//         <Table>
//           <TableHead sx={{ bgcolor: "#6e2ca3" }}>
//             <TableRow>
//               <TableCell sx={{ color: "white" }}><strong>Book Name</strong></TableCell>
//               <TableCell sx={{ color: "white" }}><strong>Author</strong></TableCell>
//               <TableCell sx={{ color: "white" }}><strong>Category</strong></TableCell>
//               <TableCell sx={{ color: "white" }}><strong>Borrow Date</strong></TableCell>
//               <TableCell sx={{ color: "white" }}><strong>Limit</strong></TableCell>
//               <TableCell sx={{ color: "white" }}><strong>Fine</strong></TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {borrowedBooks.length > 0 ? (
//               borrowedBooks.map((book) => (
//                 <TableRow key={book.id}>
//                   <TableCell>{book.name}</TableCell>
//                   <TableCell>{book.author}</TableCell>
//                   <TableCell>{book.category}</TableCell>
//                   <TableCell>{book.borrowDate}</TableCell>
//                   <TableCell>{book.limit}</TableCell>
//                   <TableCell>{book.fine}</TableCell>
//                 </TableRow>
//               ))
//             ) : (
//               <TableRow>
//                 <TableCell colSpan={6} align="center">
//                   No books borrowed yet.
//                 </TableCell>
//               </TableRow>
//             )}
//           </TableBody>
//         </Table>
//       </TableContainer>
//     </Box>
//   );
// };




import React, { useState } from "react";
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  IconButton,
} from "@mui/material";
import ReplayIcon from '@mui/icons-material/Replay'; // Import Return icon
import { StudentDashboard } from "./StudentDashboard";
import { StudentSidebar } from "./StudentSidebar";

// Initial borrowed books data
const initialBorrowedBooks = [
  { id: 1, name: "The Great Gatsby", author: "F. Scott Fitzgerald", category: "Fiction", borrowDate: "2023-08-01", limit: "18 days", fine: "0" },
  { id: 2, name: "Atomic Habits", author: "James Clear", category: "Self Help", borrowDate: "2023-08-05", limit: "10 days", fine: "0" },
  { id: 3, name: "1984", author: "George Orwell", category: "Fiction", borrowDate: "2023-08-10", limit: "12 days", fine: "0" },
  { id: 4, name: "Rich Dad Poor Dad", author: "Robert Kiyosaki", category: "Finance", borrowDate: "2023-09-01", limit: "20 days", fine: "0" },
  { id: 5, name: "Clean Code", author: "Robert C. Martin", category: "Programming", borrowDate: "2023-07-15", limit: "15 days", fine: "0" },
  { id: 6, name: "Deep Work", author: "Cal Newport", category: "Self Help", borrowDate: "2023-09-10", limit: "10 days", fine: "0" },
];

export const BorrowBook = () => {
  const [borrowedBooks, setBorrowedBooks] = useState(initialBorrowedBooks);

  // Handle return book
  const handleReturn = (id) => {
    const updatedBooks = borrowedBooks.filter((book) => book.id !== id);
    setBorrowedBooks(updatedBooks);
  };

  return (
    <>
    <StudentSidebar />
    <Box sx={{ p: 3, ml: 60, mr: 20, mt: 10 }}>
      <Typography variant="h4" gutterBottom fontWeight="bold" mb={4}>Borrow Book</Typography>

      <TableContainer component={Paper}>
        <Table>
          <TableHead sx={{ bgcolor: "#6e2ca3" }}>
            <TableRow>
              <TableCell sx={{ color: "white" }}><strong>Book Name</strong></TableCell>
              <TableCell sx={{ color: "white" }}><strong>Author</strong></TableCell>
              <TableCell sx={{ color: "white" }}><strong>Category</strong></TableCell>
              <TableCell sx={{ color: "white" }}><strong>Borrow Date</strong></TableCell>
              <TableCell sx={{ color: "white" }}><strong>Limit</strong></TableCell>
              <TableCell sx={{ color: "white" }}><strong>Fine</strong></TableCell>
              <TableCell sx={{ color: "white" }}><strong>Action</strong></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {borrowedBooks.length > 0 ? (
              borrowedBooks.map((book) => (
                <TableRow key={book.id}>
                  <TableCell>{book.name}</TableCell>
                  <TableCell>{book.author}</TableCell>
                  <TableCell>{book.category}</TableCell>
                  <TableCell>{book.borrowDate}</TableCell>
                  <TableCell>{book.limit}</TableCell>
                  <TableCell>{book.fine}</TableCell>
                  <TableCell>
                    <IconButton color="error" onClick={() => handleReturn(book.id)} title="Return Book">
                      <ReplayIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={7} align="center">
                  No books borrowed yet.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
    </>
  );
};



// import React from "react";
// import {
//   Box,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Typography,
//   IconButton,
// } from "@mui/material";
// import ReplayIcon from '@mui/icons-material/Replay';

// export const BorrowBook = ({ borrowedBooks, setBorrowedBooks }) => {
//   const handleReturn = (id) => {
//     setBorrowedBooks(borrowedBooks.filter((book) => book.id !== id));
//   };

//   return (
//     <Box sx={{ p: 3, ml: 50, mr: 20, mt: 10 }}>
//       <Typography variant="h4" gutterBottom fontWeight="bold" mb={4}>
//         Borrowed Books
//       </Typography>

//       <TableContainer component={Paper}>
//         <Table>
//           <TableHead sx={{ bgcolor: "#6e2ca3" }}>
//             <TableRow>
//               <TableCell sx={{ color: "white" }}>Book Name</TableCell>
//               <TableCell sx={{ color: "white" }}>Author</TableCell>
//               <TableCell sx={{ color: "white" }}>Category</TableCell>
//               <TableCell sx={{ color: "white" }}>Borrow Date</TableCell>
//               <TableCell sx={{ color: "white" }}>Limit</TableCell>
//               <TableCell sx={{ color: "white" }}>Fine</TableCell>
//               <TableCell sx={{ color: "white" }}>Action</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {borrowedBooks.length > 0 ? (
//               borrowedBooks.map((book) => (
//                 <TableRow key={book.id}>
//                   <TableCell>{book.name}</TableCell>
//                   <TableCell>{book.author}</TableCell>
//                   <TableCell>{book.category}</TableCell>
//                   <TableCell>{book.borrowDate}</TableCell>
//                   <TableCell>{book.limit}</TableCell>
//                   <TableCell>{book.fine}</TableCell>
//                   <TableCell>
//                     <IconButton color="error" onClick={() => handleReturn(book.id)}>
//                       <ReplayIcon />
//                     </IconButton>
//                   </TableCell>
//                 </TableRow>
//               ))
//             ) : (
//               <TableRow>
//                 <TableCell colSpan={7} align="center">
//                   No books borrowed yet.
//                 </TableCell>
//               </TableRow>
//             )}
//           </TableBody>
//         </Table>
//       </TableContainer>
//     </Box>
//   );
// };
