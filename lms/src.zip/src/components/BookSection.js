// import React, { useState } from "react";
// import {
//   Box,
//   Button,
//   TextField,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Stack,
//   Pagination,
//   IconButton,
//   InputAdornment,
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   DialogActions,
//   Divider,
//   Typography,
// } from "@mui/material";
// import SearchIcon from "@mui/icons-material/Search";
// import EditIcon from "@mui/icons-material/Edit";
// import DeleteIcon from "@mui/icons-material/Delete";
// import image from "../images/category.jpg"; // Replace with your actual image path

// const booksData = [
//   {
//     name: "Dear Zoo",
//     author: "Rod Campbell",
//     publisher: "Little Simon",
//     assignedTo: "Student",
//     copies: 5,
//   },
//   {
//     name: "The Cat in the Hat",
//     author: "Dr. Seuss",
//     publisher: "Random House",
//     assignedTo: "Student",
//     copies: 3,
//   },
//   {
//     name: "Room on the Broom",
//     author: "Julia Donaldson",
//     publisher: "Puffin Books",
//     assignedTo: "Student",
//     copies: 4,
//   },
//   {
//     name: "The Gruffalo",
//     author: "Julia Donaldson",
//     publisher: "Puffin Books",
//     assignedTo: "Student",
//     copies: 7,
//   },
//   {
//     name: "The Rainbow Fish",
//     author: "Marcus Pfister",
//     publisher: "NorthSouth Books",
//     assignedTo: "Student",
//     copies: 2,
//   },
//   {
//     name: "Good Night, Gorilla",
//     author: "Peggy Rathmann",
//     publisher: "Putnam Juvenile",
//     assignedTo: "Student",
//     copies: 6,
//   },
//   {
//     name: "The Little Engine That Could",
//     author: "Watty Piper",
//     publisher: "Grosset & Dunlap",
//     assignedTo: "Student",
//     copies: 4,
//   },
//   {
//     name: "Giraffes Can't Dance",
//     author: "Giles Andreae",
//     publisher: "Orchard Books",
//     assignedTo: "Student",
//     copies: 5,
//   },
//   {
//     name: "The Snowy Day",
//     author: "Ezra Jack Keats",
//     publisher: "Viking Books for Young Readers",
//     assignedTo: "Student",
//     copies: 8,
//   },
//   {
//     name: "Corduroy",
//     author: "Don Freeman",
//     publisher: "Viking Books for Young Readers",
//     assignedTo: "Student",
//     copies: 1,
//   },
//   {
//     name: "Brown Bear, Brown Bear",
//     author: "Bill Martin Jr.",
//     publisher: "Henry Holt",
//     assignedTo: "Student",
//     copies: 5,
//   },
//   {
//     name: "Green Eggs and Ham",
//     author: "Dr. Seuss",
//     publisher: "Random House",
//     assignedTo: "Student",
//     copies: 9,
//   },
//   {
//     name: "Where the Wild Things Are",
//     author: "Maurice Sendak",
//     publisher: "Harper Collins",
//     assignedTo: "Student",
//     copies: 6,
//   },
//   {
//     name: "The Very Hungry Caterpillar",
//     author: "Eric Carle",
//     publisher: "Philomel Books",
//     assignedTo: "Student",
//     copies: 8,
//   },
//   {
//     name: "Love You Forever",
//     author: "Robert Munsch",
//     publisher: "Firefly Books",
//     isbn: "9780920668375",
//     assignedTo: "Student",
//     copies: 5,
//   },
//   {
//     name: "Chicka Chicka Boom Boom",
//     author: "Bill Martin Jr.",
//     publisher: "Little Simon",
//     isbn: "9780689835681",
//     assignedTo: "Student",
//     copies: 4,
//   },
//   {
//     name: "Harold and the Purple Crayon",
//     author: "Crockett Johnson",
//     publisher: "HarperCollins",
//     isbn: "9780060229351",
//     assignedTo: "Student",
//     copies: 3,
//   },
// ];

// export const BookSection = () => {
//   const [books, setBooks] = useState(booksData);
//   const [searchTerm, setSearchTerm] = useState("");
//   const [currentPage, setCurrentPage] = useState(1);
//   const [openDialog, setOpenDialog] = useState(false);
//   const [editingBook, setEditingBook] = useState(null);

//   const [newBook, setNewBook] = useState({
//     name: "",
//     author: "",
//     publisher: "",
//     assignedTo: "",
//     copies: "",
//   });

//   const itemsPerPage = 5;

//   const handleOpen = () => {
//     setEditingBook(null);
//     setOpenDialog(true);
//   };

//   const handleClose = () => {
//     setOpenDialog(false);
//     setNewBook({ name: "", author: "", publisher: "", assignedTo: "", copies: "" });
//   };

//   const handleAddBook = () => {
//     if (!newBook.name.trim()) return alert("Book name is required");

//     const newId = books.length > 0 ? books[books.length - 1].id + 1 : 1;
//     setBooks([...books,
//     {
//       id: newId,
//       name: newBook.name.trim(),
//       author: newBook.author.trim(),
//       publisher: newBook.publisher.trim(),
//       assignedTo: parseInt(newBook.assignedTo),
//       copies: newBook.copies.trim(),
//     }]);
//     handleClose();
//   };

//   const handleEditBook = () => {

//   }

//   const handleDelete = (id) => {
//     setBooks((prev) => prev.filter((book) => book.id !== id));
//   };

//   const handleEdit = (book) => {
//     setEditingBook(book);
//     setNewBook(book);
//     setOpenDialog(true);
//   };

//   const handleSearch = (e) => {
//     setSearchTerm(e.target.value);
//     setCurrentPage(1);
//   };

//   const filteredBooks = books.filter((book) =>
//     book.name.toLowerCase().includes(searchTerm.toLowerCase())
//   );

//   const totalPages = Math.ceil(filteredBooks.length / itemsPerPage);
//   const paginatedBooks = filteredBooks.slice(
//     (currentPage - 1) * itemsPerPage,
//     currentPage * itemsPerPage
//   );

//   return (
//     <Box sx={{ p: 3, ml: 50, mr: 20, mt: 10 }}>
//       <Typography variant="h4" sx={{ mb: 3 }}>Books</Typography>

//       {/* Search and Add Button */}
//       <Box
//         sx={{
//           backgroundColor: "#fff",
//           display: "flex",
//           justifyContent: "space-between",
//           alignItems: "center",
//           mb: 2,
//         }}
//       >
//         <TextField
//           placeholder="Search by Book Name"
//           variant="outlined"
//           value={searchTerm}
//           onChange={handleSearch}
//           sx={{ width: 400 }}
//           InputProps={{
//             startAdornment: (
//               <InputAdornment position="start">
//                 <SearchIcon />
//               </InputAdornment>
//             ),
//           }}
//         />
//         <Button variant="contained" onClick={handleOpen} sx={{ backgroundColor: "#6e2ca3" }}>
//           Add Book
//         </Button>
//       </Box>

//     {/* Table */}
// <TableContainer component={Paper}>
//         <Table>
//           <TableHead sx={{ bgcolor: "#6e2ca3" }}>
//             <TableRow>
//               <TableCell sx={{ color: "white" }}>Book Name</TableCell>
//               <TableCell sx={{ color: "white" }}>Author</TableCell>
//               <TableCell sx={{ color: "white" }}>Publisher</TableCell>
//               <TableCell sx={{ color: "white" }}>Assigned To</TableCell>
//               <TableCell sx={{ color: "white" }}>Available Copies</TableCell>
//               <TableCell sx={{ color: "white" }}>Actions</TableCell>
//             </TableRow>
//           </TableHead>

//           <TableBody>
//             {paginatedBooks.map((book) => (
//               <TableRow key={book.id}>
//                 <TableCell>{book.name}</TableCell>
//                 <TableCell>{book.author}</TableCell>
//                 <TableCell>{book.publisher}</TableCell>
//                 <TableCell>{book.assignedTo}</TableCell>
//                 <TableCell>{book.copies}</TableCell> {/* New Column */}
//                 <TableCell>
//                   <IconButton color="primary" onClick={() => handleEdit(book)}>
//                     <EditIcon />
//                   </IconButton>
//                   <IconButton color="error" onClick={() => handleDelete(book.id)}>
//                     <DeleteIcon />
//                   </IconButton>
//                 </TableCell>
//               </TableRow>
//             ))}
//             {paginatedBooks.length === 0 && (
//               <TableRow>
//                 <TableCell colSpan={6} align="center">No books found.</TableCell>
//               </TableRow>
//             )}
//           </TableBody>

//         </Table>
//       </TableContainer>

//        {/* Pagination */}
//       {totalPages > 1 && (
//         <Stack direction="row" justifyContent="center" sx={{ mt: 2 }}>
//           <Pagination
//             count={totalPages}
//             page={currentPage}
//             onChange={(e, value) => setCurrentPage(value)}
//           />
//         </Stack>
//       )}

//   {/* Add Book Dialog */}
//       <Dialog open={openDialog} onClose={handleClose} maxWidth="md" fullWidth>
//         <DialogTitle>Add New Book</DialogTitle>
//         <Divider sx={{ mb: 2 }} />
//         <Box sx={{ display: "flex", gap: 4, p: 3 }}>
//           <Box>
//             <img src={image} alt="book" style={{ width: 420, height: 400, objectFit: "cover", borderRadius: 8 }} />
//           </Box>
//           <Box sx={{ flex: 1, display: "flex", flexDirection: "column", gap: 2, mt: 6 }}>
//             <TextField label="Book Name" value={newBook.name} onChange={(e) => setNewBook({ ...newBook, name: e.target.value })} required />
//             <TextField label="Author" value={newBook.author} onChange={(e) => setNewBook({ ...newBook, description: e.target.value })} multiline rows={3} />
//             <TextField label="Publisher" value={newBook.publisher} onChange={(e) => setNewBook({ ...newBook, publisher: e.target.value })} required />
//             <TextField label="Assign To" value={newBook.assignedTo} onChange={(e) => setNewBook({ ...newBook, assignedTo: e.target.value })} required />
//             <TextField label="Available Copies" value={newBook.copies} onChange={(e) => setNewBook({ ...newBook, copies: e.target.value })} required />
//           </Box>
//         </Box>
//         <DialogActions>
//           <Button onClick={handleClose} color="secondary">Cancel</Button>
//           <Button onClick={handleAddBook} variant="contained" sx={{ backgroundColor: "#6e2ca3" }}>Save</Button>
//         </DialogActions>
//       </Dialog>




//        {/* Edit Category Dialog */}
//             <Dialog open={openEditDialog} onClose={handleEditClose} maxWidth="md" fullWidth>
//               <DialogTitle>Edit Category</DialogTitle>
//               <Divider sx={{ mb: 2 }} />
//               <Box sx={{ display: "flex", gap: 4, p: 3 }}>
//                 <Box>
//                   <img src={img} alt="Category" style={{ width: 420, height: 400, objectFit: "cover", borderRadius: 8 }} />
//                 </Box>
//                 <Box sx={{ flex: 1, display: "flex", flexDirection: "column", gap: 2, mt:6 }}>
//                   <TextField label="Category Name" value={editingCategory?.name || ""} onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })} required />
//                   <TextField label="Description" value={editingCategory?.description || ""} onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })} multiline rows={3} />
//                   {/* <TextField label="Total Books" type="number" value={editingCategory?.totalBooks || ""} onChange={(e) => setEditingCategory({ ...editingCategory, totalBooks: e.target.value })} required /> */}
//                   <TextField label="Status" value={editingCategory?.status || ""} onChange={(e) => setEditingCategory({ ...editingCategory, status: e.target.value })} required placeholder="Active or Inactive" />
//                 </Box>
//               </Box>
//               <DialogActions>
//                 <Button onClick={handleEditClose} color="secondary">Cancel</Button>
//                 <Button onClick={handleUpdateCategory} variant="contained" sx={{ backgroundColor: "#6e2ca3" }}>Update</Button>
//               </DialogActions>
//             </Dialog>


//     </Box>
//   );
// };



import React, { useState } from "react";
import {
  Box,
  Button,
  TextField,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Stack,
  Pagination,
  IconButton,
  InputAdornment,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Divider,
  Typography,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import image from "../images/category.jpg";
import { SidebarSection } from "./SidebarSection";

const initialBooks = [
  {
    id:1,
    name: "Dear Zoo",
    author: "Rod Campbell",
    publisher: "Little Simon",
    categories: "Science",
    copies: 5,
  },
  {
    id:2,
    name: "The Cat in the Hat",
    author: "Dr. Seuss",
    publisher: "Random House",
    categories: "Literature",
    copies: 3,
  },
  {
    id:3,
    name: "Room on the Broom",
    author: "Julia Donaldson",
    publisher: "Puffin Books",
    categories: "History",
    copies: 4,
  },
  {
    id:4,
    name: "The Gruffalo",
    author: "Julia Donaldson",
    publisher: "Puffin Books",
    categories: "Art",
    copies: 7,
  },
  {
    id:5,
    name: "The Rainbow Fish",
    author: "Marcus Pfister",
    publisher: "NorthSouth Books",
    categories: "Mathematics",
    copies: 2,
  },
  {
    id:6,
    name: "Good Night, Gorilla",
    author: "Peggy Rathmann",
    publisher: "Putnam Juvenile",
    categories: "Philosophy",
    copies: 6,
  },
  {
    id:7,
    name: "The Little Engine That Could",
    author: "Watty Piper",
    publisher: "Grosset & Dunlap",
    categories: "Technology",
    copies: 4,
  },
  {
    id:8,
    name: "Giraffes Can't Dance",
    author: "Giles Andreae",
    publisher: "Orchard Books",
    categories: "Travel	",
    copies: 5,
  },
  {
    id:9,
    name: "The Snowy Day",
    author: "Ezra Jack Keats",
    publisher: "Viking Books for Young Readers",
    categories: "Cooking",
    copies: 8,
  },
  {
    id:10,
    name: "Corduroy",
    author: "Don Freeman",
    publisher: "Viking Books for Young Readers",
    categories: "Health",
    copies: 1,
  },
  {
    id:11,
    name: "Brown Bear, Brown Bear",
    author: "Bill Martin Jr.",
    publisher: "Henry Holt",
    categories: "Sports	",
    copies: 5,
  },
  {
    id:12,
    name: "Green Eggs and Ham",
    author: "Dr. Seuss",
    publisher: "Random House",
    categories: "Business",
    copies: 9,
  },
  {
    id:13,
    name: "Where the Wild Things Are",
    author: "Maurice Sendak",
    publisher: "Harper Collins",
    categories: "Biography",
    copies: 6,
  },
  {
    id:14,
    name: "The Very Hungry Caterpillar",
    author: "Eric Carle",
    publisher: "Philomel Books",
    categories: "Children",
    copies: 8,
  },
  {
    id:15,
    name: "Love You Forever",
    author: "Robert Munsch",
    publisher: "Firefly Books",
    isbn: "9780920668375",
    categories: "Fantasy",
    copies: 5,
  },
  {
    id:16,
    name: "Chicka Chicka Boom Boom",
    author: "Bill Martin Jr.",
    publisher: "Little Simon",
    isbn: "9780689835681",
    categories: "Mystery",
    copies: 4,
  },
  {
    id:17,
    name: "Harold and the Purple Crayon",
    author: "Crockett Johnson",
    publisher: "HarperCollins",
    isbn: "9780060229351",
    categories: "Fiction",
    copies: 3,
  },
];

export const BookSection = () => {
  const [books, setBooks] = useState(initialBooks);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);

  const [openAddDialog, setOpenAddDialog] = useState(false);
  const [openEditDialog, setOpenEditDialog] = useState(false);

  const [newBook, setNewBook] = useState({
    name: "",
    author: "",
    publisher: "",
    categories: "",
    copies: "",
  });

  const [editingBook, setEditingBook] = useState(null);

  const itemsPerPage = 5;

  const handleOpenAdd = () => {
    setNewBook({ name: "", author: "", publisher: "", categories: "", copies: "" });
    setOpenAddDialog(true);
  };

  const handleCloseAdd = () => {
    setOpenAddDialog(false);
  };

  const handleAddBook = () => {
    if (!newBook.name.trim()) return alert("Book name is required");

    const newId = books.length > 0 ? books[books.length - 1].id + 1 : 1;
    setBooks([...books,
    {
      id: newId,
      name: newBook.name.trim(),
      author: newBook.author.trim(),
      publisher: newBook.publisher.trim(),
      categories: newBook.categories,
      copies: newBook.copies.trim(),
    }]);
    handleCloseAdd();
  };

  const handleEdit = (book) => {
    setEditingBook(book);
    setOpenEditDialog(true);
  };

  const handleCloseEdit = () => {
    setOpenEditDialog(false);
    setEditingBook();
  };

const handleUpdateBook = () => {
  if (!editingBook.name.trim()) return alert("Book name is required");
  if (!editingBook.author.trim()) return alert("Book author is required");
  if (!editingBook.publisher.trim()) return alert("Book publisher is required");
  if (!editingBook.categories.trim()) return alert("Book assignedTo is required");
  if (!editingBook.copies) return alert("Book copies is required");

  setBooks((prevBooks) =>
    prevBooks.map((book) =>
      book.id === editingBook.id
        ? {
            ...book,
            name: editingBook.name.trim(),
            author: editingBook.author.trim(),
            publisher: editingBook.publisher.trim(),
            categories: editingBook.categories.trim(), 
            copies: parseInt(editingBook.copies), 
          }
        : book
    )
  );
  handleCloseEdit();
};

  const handleDelete = (id) => {
    setBooks((prev) => prev.filter((book) => book.id !== id));
  };

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  };

  const filteredBooks = books.filter((book) =>
    book.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalPages = Math.ceil(filteredBooks.length / itemsPerPage);
  const paginatedBooks = filteredBooks.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <>
    <SidebarSection />
    <Box sx={{ p: 3, ml: 50, mr: 20, mt: 10 }}>
      <Typography variant="h4" sx={{ mb: 3 }} fontWeight="bold">Books</Typography>

      {/* Search and Add Button */}
      <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
        <TextField
          placeholder="Search by Book Name"
          variant="outlined"
          value={searchTerm}
          onChange={handleSearch}
          sx={{ width: 400 }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
        <Button variant="contained" onClick={handleOpenAdd} sx={{ backgroundColor: "#6e2ca3" }}>
          Add Book
        </Button>
      </Box>

      {/* Table */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead sx={{ bgcolor: "#6e2ca3" }}>
            <TableRow>
              <TableCell sx={{ color: "white" }}>Book Name</TableCell>
              <TableCell sx={{ color: "white" }}>Author</TableCell>
              <TableCell sx={{ color: "white" }}>Publisher</TableCell>
              <TableCell sx={{ color: "white" }}>Categories</TableCell>
              <TableCell sx={{ color: "white" }}>Copies</TableCell>
              <TableCell sx={{ color: "white" }}>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {paginatedBooks.map((book) => (
              <TableRow key={book.id}>
                <TableCell>{book.name}</TableCell>
                <TableCell>{book.author}</TableCell>
                <TableCell>{book.publisher}</TableCell>
                <TableCell>{book.categories}</TableCell>
                <TableCell>{book.copies}</TableCell>
                <TableCell>
                  <IconButton color="primary" onClick={() => handleEdit(book)}>
                    <EditIcon />
                  </IconButton>
                  <IconButton color="error" onClick={() => handleDelete(book.id)}>
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
            {paginatedBooks.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} align="center">No books found.</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Pagination */}
      {totalPages > 1 && (
        <Stack direction="row" justifyContent="center" sx={{ mt: 2 }}>
          <Pagination
            count={totalPages}
            page={currentPage}
            onChange={(e, value) => setCurrentPage(value)}
          />
        </Stack>
      )}

      {/* Add Dialog */}
      <Dialog open={openAddDialog} onClose={handleCloseAdd} maxWidth="md" fullWidth>
        <DialogTitle>Add New Book</DialogTitle>
        <Divider sx={{ mb: 2 }} />
        <DialogContent>
          <Box sx={{ display: "flex", gap: 4 }}>
            <Box>
              <img src={image} alt="book" style={{ width: 420, height: 400, objectFit: "cover", borderRadius: 8 }} />
            </Box>
            <Box sx={{ flex: 1, display: "flex", flexDirection: "column", gap: 2 }}>
              <TextField label="Book Name" value={newBook.name} onChange={(e) => setNewBook({ ...newBook, name: e.target.value })} required />
              <TextField label="Author" value={newBook.author} onChange={(e) => setNewBook({ ...newBook, author: e.target.value })} />
              <TextField label="Publisher" value={newBook.publisher} onChange={(e) => setNewBook({ ...newBook, publisher: e.target.value })} />
              <TextField label="Assign To" value={newBook.categories} onChange={(e) => setNewBook({ ...newBook, categories: e.target.value })} />
              <TextField label="Copies" type="number" value={newBook.copies} onChange={(e) => setNewBook({ ...newBook, copies: e.target.value })} />
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseAdd}>Cancel</Button>
          <Button onClick={handleAddBook} variant="contained" sx={{ backgroundColor: "#6e2ca3" }}>Save</Button>
        </DialogActions>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={openEditDialog} onClose={handleCloseEdit} maxWidth="md" fullWidth>
        <DialogTitle>Edit Book</DialogTitle>
        <Divider sx={{ mb: 2 }} />
        <DialogContent>
          <Box sx={{ display: "flex", gap: 4 }}>
            <Box>
              <img src={image} alt="book" style={{ width: 420, height: 400, objectFit: "cover", borderRadius: 8 }} />
            </Box>
            <Box sx={{ flex: 1, display: "flex", flexDirection: "column", gap: 2 }}>
              <TextField label="Book Name" value={editingBook?.name || ""} onChange={(e) => setEditingBook({ ...editingBook, name: e.target.value })} required />
              <TextField label="Author" value={editingBook?.author || ""} onChange={(e) => setEditingBook({ ...editingBook, author: e.target.value })} />
              <TextField label="Publisher" value={editingBook?.publisher || ""} onChange={(e) => setEditingBook({ ...editingBook, publisher: e.target.value })} />
              <TextField label="Assign To" value={editingBook?.categories || ""} onChange={(e) => setEditingBook({ ...editingBook, categories: e.target.value })} />
              <TextField label="Copies" type="number" value={editingBook?.copies || ""} onChange={(e) => setEditingBook({ ...editingBook, copies: parseInt(e.target.value) })} />
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseEdit}>Cancel</Button>
          <Button onClick={handleUpdateBook} variant="contained" sx={{ backgroundColor: "#6e2ca3" }}>Update</Button>
        </DialogActions>
      </Dialog>
    </Box>
    </>
  );
};
