// import React, { useState } from "react";
// import {
//   Box,
//   Typography,
//   TextField,
//   Button,
//   Link,
//   Paper,
// } from "@mui/material";
// import image from "../images/register-img.png";
// import { useNavigate } from "react-router-dom";

// export const RegisterPage = () => {
//   const [name, setName] = useState("");
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const navigate = useNavigate();

//   const handleRegister = (e) => {
//     e.preventDefault();
//     navigate("/dashboard");
//   };

//   return (
//     <Box
//       sx={{
//         minHeight: "86vh",
//         backgroundColor: "#e9e0f6",
//         display: "flex",
//         // justifyContent: "center",
//         paddingLeft: 62,
//         alignItems: "center",
//         marginTop: 9,
//         paddingBottom: 5

//       }}
//     >
//       <Paper
//         sx={{
//           display: "flex",
//           flexDirection: { xs: "column", md: "row" },
//           borderRadius: 4,
//           overflow: "hidden",
//           maxWidth: 1000,
//         }}
//       >
//         {/* Left: Image */}
//         <Box
//           sx={{
//             flex: 1,
//             backgroundColor: "#fff",
//             display: "flex",
//             justifyContent: "flex-start",
//             alignItems: "center",
//             p: 2,
//           }}
//         >
//           <Box
//             component="img"
//             src={image}
//             alt="Library register"
//             sx={{
//               width: 400,
//               maxWidth: 600,
//               height: 600,
//               objectFit: "cover",
//               borderRadius: 2,
//             }}
//           />
//         </Box>

//         {/* Right: Register Form */}
//         <Box
//           sx={{
//             p: { xs: 3, md: 5 },
//             display: "flex",
//             flexDirection: "column",
//             justifyContent: "center",
//             backgroundColor: "#fff",
//             height: 600,
//             width: 450
//           }}
//         >
//           <Typography variant="h5" fontWeight="bold" align="center" mb={2}>
//             Register
//           </Typography>

//           <form onSubmit={handleRegister}>

//             <TextField
//               margin="normal"
//               fullWidth
//               label="User Name"
//               type="name"
//               value={name}
//               onChange={(e) => setName(e.target.value)}
//             />

//             <TextField
//               margin="normal"
//               fullWidth
//               label="Email"
//               type="email"
//               name="email"
//               value={email}
//               onChange={(e) => setEmail(e.target.value)}

//             />

//             <TextField
//               margin="normal"
//               fullWidth
//               label="Password"
//               type="password"
//               name="password"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//             />

//             <Box
//               sx={{
//                 display: "flex",
//                 justifyContent: "space-between",
//                 alignItems: "center",
//                 width: 400,
//                 mt: 1,
//                 mb: 2,
//               }}
//             >
//               <Link href="#" variant="body2" underline="none">
//                 Forget Password?
//               </Link>
//             </Box>

//             <Button
//               type="submit"
//               fullWidth
//               variant="contained"
//               sx={{
//                 backgroundColor: "#6e2ca3",
//                 color: "white",
//                 textTransform: "none",
//                 py: 1.5,
//                 fontWeight: "bold",
//                 borderRadius: 2,
//               }}
//             >
//               Register
//             </Button>
//           </form>
//         </Box>
//       </Paper>
//     </Box>
//   );
// };




// import React, { useState } from "react";
// import {
//   Box,
//   Typography,
//   TextField,
//   Button,
//   Link,
//   Paper,
//   Radio,
//   RadioGroup,
//   FormControlLabel,
//   FormControl,
//   FormLabel,
//   Checkbox,
// } from "@mui/material";
// import image from "../images/register-img.png";
// import { useNavigate } from "react-router-dom";

// export const RegisterPage = () => {
//   const [name, setName] = useState("");
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [department, setDepartment] = useState("");
//   const [year, setYear] = useState("");
//   const [role, setRole] = useState("student");
//   const [remember, setRemember] = useState(false);
//   const navigate = useNavigate();

//   // const handleRegister = (e) => {
//   //   e.preventDefault();
//   //   // Handle form data submission here
//   //   console.log({ name, email, password, department, year, role, remember });
//   //   navigate("/dashboard");
//   // };
// const handleSubmit = (e) => {
//         e.preventDefault();
//         if (isLogin) {
//             console.log("Student with:", { email, password });
//             navigate("/register");
//         } else {
//             console.log("Admin with:", { name, email, password });
//             navigate("/register");
//         }
//     };


//   return (
//     <Box
//       sx={{
//         minHeight: "86vh",
//         backgroundColor: "#e9e0f6",
//         display: "flex",
//         paddingLeft: 62,
//         alignItems: "center",
//         marginTop: 9,
//         paddingBottom: 5,
//       }}
//     >
//       <Paper
//         sx={{
//           display: "flex",
//           flexDirection: { xs: "column", md: "row" },
//           borderRadius: 4,
//           overflow: "hidden",
//           maxWidth: 1000,
//         }}
//       >
//         {/* Left: Image */}
//         <Box
//           sx={{
//             flex: 1,
//             backgroundColor: "#fff",
//             display: "flex",
//             justifyContent: "flex-start",
//             alignItems: "center",
//             p: 2,
//           }}
//         >
//           <Box
//             component="img"
//             src={image}
//             alt="Library register"
//             sx={{
//               width: 400,
//               maxWidth: 600,
//               height: 600,
//               objectFit: "cover",
//               borderRadius: 2,
//             }}
//           />
//         </Box>

//         {/* Right: Register Form */}
//         <Box
//           sx={{
//             p: { xs: 3, md: 5 },
//             display: "flex",
//             flexDirection: "column",
//             justifyContent: "center",
//             // backgroundColor: "#1b1b32",
//             color: "white",
//             height: 600,
//             width: 450,
//           }}
//         >
//           <Typography variant="h5" fontWeight="bold" align="center" mb={2}>
//             Register
//           </Typography>

//           <form onSubmit={handleRegister}>
//             <TextField
//               margin="normal"
//               fullWidth
//               label="Full Name"
//               value={name}
//               onChange={(e) => setName(e.target.value)}

//             />

//             <TextField
//               margin="normal"
//               fullWidth
//               label="Email"
//               type="email"
//               value={email}
//               onChange={(e) => setEmail(e.target.value)}

//             />

//             <TextField
//               margin="normal"
//               fullWidth
//               label="Password"
//               type="password"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}

//             />

//             <TextField
//               margin="normal"
//               fullWidth
//               label="Department"
//               value={department}
//               onChange={(e) => setDepartment(e.target.value)}

//             />

//             <TextField
//               margin="normal"
//               fullWidth
//               label="Year"
//               value={year}
//               onChange={(e) => setYear(e.target.value)}


//             />
//             <Box sx={{ display: "flex", alignItems: "center" }}>
//               <FormControl component="fieldset" sx={{ mt: 2, }}>
//                 <RadioGroup
//                   row
//                   value={role}
//                   onChange={(e) => setRole(e.target.value)}
//                 >
//                   <FormControlLabel
//                     value="student"
//                     control={<Radio />}
//                     label="Student"
//                     sx={{ color: "black" }}
//                   />
//                   <FormControlLabel
//                     value="admin"
//                     control={<Radio />}
//                     label="Admin"
//                     sx={{ color: "black" }}
//                   />
//                 </RadioGroup>
//               </FormControl>

//               <FormControlLabel
//                 control={
//                   <Checkbox
//                     checked={remember}
//                     onChange={(e) => setRemember(e.target.checked)}

//                   />
//                 }
//                 label="Remember me"
//                 sx={{ mt: 1, color: "black" }}
//               />

//             </Box>

//             <Button
//               type="submit"
//               fullWidth
//               variant="contained"
//               sx={{
//                 backgroundColor: "#6e2ca3",
//                 color: "white",
//                 textTransform: "none",
//                 py: 1.5,
//                 fontWeight: "bold",
//                 borderRadius: 2,
//                 mt: 2,
//               }}
//             >
//               Register
//             </Button>

//             <Typography variant="body2" align="center" mt={2} sx={{ color: "black" }}>
//               Already have an account?{" "}
//               <Link href="/login" underline="hover">
//                 Login
//               </Link>
//             </Typography>
//           </form>
//         </Box>
//       </Paper>
//     </Box>
//   );
// };



// import React, { useState } from "react";
// import {
//   Box,
//   Typography,
//   TextField,
//   Button,
//   Link,
//   Paper,
//   Radio,
//   RadioGroup,
//   FormControlLabel,
//   FormControl,
//   Checkbox,
// } from "@mui/material";
// import image from "../images/register-img.png";
// import { useNavigate } from "react-router-dom";
// import { AdminRegister } from "../components/AdminRegister"; 

// export const RegisterPage = () => {
//   const [name, setName] = useState("");
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [department, setDepartment] = useState("");
//   const [year, setYear] = useState("");
//   const [role, setRole] = useState("student");
//   const [remember, setRemember] = useState(false);
//   const navigate = useNavigate();

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     const formData = {
//       name,
//       email,
//       password,
//       department,
//       year,
//       role,
//       remember,
//     };

//     console.log("Form Data:", formData);
//     navigate("/dashboard");
//   };

//   // ✅ If role is admin, show AdminRegisterPage instead
//   if (role === "admin") {
//     return <AdminRegister />;
//   }

//   return (
//     <Box
//       sx={{
//         minHeight: "86vh",
//         backgroundColor: "#e9e0f6",
//         display: "flex",
//         paddingLeft: 62,
//         alignItems: "center",
//         marginTop: 9,
//         paddingBottom: 5,
//       }}
//     >
//       <Paper
//         sx={{
//           display: "flex",
//           flexDirection: { xs: "column", md: "row" },
//           borderRadius: 4,
//           overflow: "hidden",
//           maxWidth: 1000,
//         }}
//       >
//         {/* Left: Image */}
//         <Box
//           sx={{
//             flex: 1,
//             backgroundColor: "#fff",
//             display: "flex",
//             justifyContent: "flex-start",
//             alignItems: "center",
//             p: 2,
//           }}
//         >
//           <Box
//             component="img"
//             src={image}
//             alt="Library register"
//             sx={{
//               width: 400,
//               maxWidth: 600,
//               height: 600,
//               objectFit: "cover",
//               borderRadius: 2,
//             }}
//           />
//         </Box>

//         {/* Right: Student Register Form */}
//         <Box
//           sx={{
//             p: { xs: 3, md: 5 },
//             display: "flex",
//             flexDirection: "column",
//             justifyContent: "center",
//             color: "white",
//             height: 600,
//             width: 450,
//           }}
//         >
//           <Typography variant="h5" fontWeight="bold" align="center" mb={2} sx={{ color: "black" }}>
//            Student Register 
//           </Typography>

//           <form onSubmit={handleSubmit}>
//             <TextField
//               margin="normal"
//               fullWidth
//               label="Full Name"
//               value={name}
//               onChange={(e) => setName(e.target.value)}
//             />

//             <TextField
//               margin="normal"
//               fullWidth
//               label="Email"
//               type="email"
//               value={email}
//               onChange={(e) => setEmail(e.target.value)}
//             />

//             <TextField
//               margin="normal"
//               fullWidth
//               label="Password"
//               type="password"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//             />

//             <TextField
//               margin="normal"
//               fullWidth
//               label="Department"
//               value={department}
//               onChange={(e) => setDepartment(e.target.value)}
//             />

//             <TextField
//               margin="normal"
//               fullWidth
//               label="Year"
//               value={year}
//               onChange={(e) => setYear(e.target.value)}
//             />

//             <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", mt: 2 }}>
//               <FormControl>
//                 <RadioGroup
//                   row
//                   value={role}
//                   onChange={(e) => setRole(e.target.value)}
//                 >
//                   <FormControlLabel
//                     value="student"
//                     control={<Radio />}
//                     label="Student"
//                     sx={{ color: "black" }}
//                   />
//                   <FormControlLabel
//                     value="admin"
//                     control={<Radio />}
//                     label="Admin"
//                     sx={{ color: "black" }}
//                   />
//                 </RadioGroup>
//               </FormControl>

//               <FormControlLabel
//                 control={
//                   <Checkbox
//                     checked={remember}
//                     onChange={(e) => setRemember(e.target.checked)}
//                   />
//                 }
//                 label="Remember me"
//                 sx={{ color: "black" }}
//               />
//             </Box>

//             <Button
//               type="submit"
//               fullWidth
//               variant="contained"
//               sx={{
//                 backgroundColor: "#6e2ca3",
//                 color: "white",
//                 textTransform: "none",
//                 py: 1.5,
//                 fontWeight: "bold",
//                 borderRadius: 2,
//                 mt: 2,
//               }}
//             >
//               Register
//             </Button>

//             <Typography variant="body2" align="center" mt={2} sx={{ color: "black" }}>
//               Already have an account?{" "}
//               <Link href="/login" underline="hover">
//                 Login
//               </Link>
//             </Typography>
//           </form>
//         </Box>
//       </Paper>
//     </Box>
//   );
// };



import React, { useState } from "react";
import {
  Box,
  Typography,
  TextField,
  Button,
  Link,
  Paper,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormControl,
  Checkbox,
} from "@mui/material";
import image from "../images/register-img.png";
import { useNavigate } from "react-router-dom";

export const RegisterPage = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [department, setDepartment] = useState("");
  const [year, setYear] = useState("");
  const [role, setRole] = useState("student");
  const [remember, setRemember] = useState(false);

  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    const formData = {
      name,
      email,
      password,
      department,
      year,
      role,
      remember,
    };

    console.log("Form Data:", formData);
    navigate("/sign");
  };

  return (
    <Box
      sx={{
        minHeight: "86vh",
        backgroundColor: "#e9e0f6",
        display: "flex",
        paddingLeft: 45,
        paddingTop: 7,
        paddingBottom: 7,
      }}
    >
      <Paper
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          borderRadius: 4,
          overflow: "hidden",
          maxWidth: 1000,
        }}
      >
        {/* Left: Image */}
        <Box
          sx={{
            flex: 1,
            backgroundColor: "#fff",
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
            p: 2,
          }}
        >
          <Box
            component="img"
            src={image}
            alt="Library register"
            sx={{
              width: 400,
              maxWidth: 600,
              height: 600,
              objectFit: "cover",
              borderRadius: 2,
            }}
          />
        </Box>

        {/* Right: Register Form */}
        <Box
          sx={{
            p: { xs: 3, md: 5 },
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            color: "white",
            height: 600,
            width: 450,
          }}
        >
          <Typography
            variant="h5"
            fontWeight="bold"
            align="center"
            mb={2}
            sx={{ color: "black" }}
          >
            {role === "student" ? "Student Register" : "Admin Register"}
          </Typography>

          <form onSubmit={handleSubmit}>
            {/* Common Fields */}
            <TextField
              margin="normal"
              fullWidth
              label="Full Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />

            <TextField
              margin="normal"
              fullWidth
              label="Email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            <TextField
              margin="normal"
              fullWidth
              label="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />

            {/* Student-Specific Fields */}
            {role === "student" && (
              <>
                <TextField
                  margin="normal"
                  fullWidth
                  label="Department"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                />

                <TextField
                  margin="normal"
                  fullWidth
                  label="Year"
                  value={year}
                  onChange={(e) => setYear(e.target.value)}
                />
              </>
            )}

            {/* Role and Remember Me */}
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                mt: 2,
              }}
            >
              <FormControl>
                <RadioGroup
                  row
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                >
                  <FormControlLabel
                    value="student"
                    control={<Radio />}
                    label="Student"
                    sx={{ color: "black" }}
                  />
                  <FormControlLabel
                    value="admin"
                    control={<Radio />}
                    label="Admin"
                    sx={{ color: "black" }}
                  />
                </RadioGroup>
              </FormControl>

              <FormControlLabel
                control={
                  <Checkbox
                    checked={remember}
                    onChange={(e) => setRemember(e.target.checked)}
                  />
                }
                label="Remember me"
                sx={{ color: "black" }}
              />
            </Box>

            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{
                backgroundColor: "#6e2ca3",
                color: "white",
                textTransform: "none",
                py: 1.5,
                fontWeight: "bold",
                borderRadius: 2,
                mt: 2,
              }}
            >
              Register
            </Button>

            <Typography
              variant="body2"
              align="center"
              mt={2}
              sx={{ color: "black" }}
            >
              Already have an account?{" "}
              <Link href="/sign" underline="hover">
                Login
              </Link>
            </Typography>
          </form>
        </Box>
      </Paper>
    </Box>
  );
};
