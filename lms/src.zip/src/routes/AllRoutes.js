// import React from "react";
//  import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";

// import { SidebarSection } from './components/SidebarSection';
// import { RegisterPage } from './components/RegisterPage';
// import { SigninPage } from './components/SigninPage';
// import { CategoriesSection } from "./components/CategoriesSection";
// import { BookSection } from './components/BookSection';
// import { LogoutPage } from "./components/LogoutPage";
// import { Dashboard } from "./components/Dashboard";
// import { StudentMembership } from "./components/StudentMembership";
// import { BorrowBook } from "./components/BorrowBook";
// import { ReturnBook } from "./components/ReturnBook";
// import { StudentDashboard } from './components/StudentDashboard';
// import { StudentHistory } from './components/StudentHistory';
// import { BrowseBooks } from './components/BrowseBooks';


// const Layout = ({ children }) => {
//   const location = useLocation();


//   const hideSidebarRoutes = [ "/sign","/register", "/logout"];

//   const hideSidebar = hideSidebarRoutes.includes(location.pathname);

//   return (
//     <>
//       {!hideSidebar && <SidebarSection />}
//       {children}
//     </>
//   );
// };

// export const AllRoutes() {
//   return (
//     <div className="App">
//       <Router>
//         <Layout>
//           <Routes>
//             <Route path="/sign" element={<SigninPage />} />
//             <Route path="/register" element={<RegisterPage />} />
//             <Route path="/logout" element={<LogoutPage />} />
//             <Route path="/categories" element={<CategoriesSection />} />
//             <Route path="/books" element={<BookSection />} />
//             <Route path="/membership" element={<StudentMembership />} />
//             <Route path="/browsebooks" element={<BrowseBooks />} />
//             <Route path="/borrow" element={<BorrowBook />} />
//             <Route path="/student-history" element={<StudentHistory />} />
          
//             <Route path="/" element={<Dashboard />} />
//                         <Route path="/student" element={<StudentDashboard />} />
//           </Routes>
//         </Layout>
//       </Router>
//     </div>
//   );
// }


import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { RegisterPage } from "../components/RegisterPage";
import { SigninPage } from "../components/SigninPage";
import { CategoriesSection } from "../components/CategoriesSection";
import { BookSection } from "../components/BookSection";
import { LogoutPage } from "../components/LogoutPage";
import { Dashboard } from "../components/Dashboard";
import { StudentMembership } from "../components/StudentMembership";
import { BorrowBook } from "../components/BorrowBook";
import { StudentDashboard } from "../components/StudentDashboard";
import { StudentHistory } from "../components/StudentHistory";
import { BrowseBooks } from "../components/BrowseBooks";

// All Routes Component
const AllRoutes = () => {
  return (
    <Router>
        <Routes>
          <Route path="/sign" element={<SigninPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/logout" element={<LogoutPage />} />
          <Route path="/categories" element={<CategoriesSection />} />
          <Route path="/books" element={<BookSection />} />
          <Route path="/membership" element={<StudentMembership />} />
          <Route path="/" element={<Dashboard />} />
          <Route path="/browsebooks" element={<BrowseBooks />} />
          <Route path="/borrow" element={<BorrowBook />} />
          <Route path="/student-history" element={<StudentHistory />} />
          <Route path="/student" element={<StudentDashboard />} />
          
        </Routes>
    </Router>
  );
};

export default AllRoutes;

