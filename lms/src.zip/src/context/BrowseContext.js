// components/BorrowContext.jsx
import React, { createContext, useContext, useState } from "react";

const BorrowContext = createContext();

const initialBorrowedBooks = [
  {
    id: 1,
    name: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    category: "Fiction",
    borrowDate: "2023-08-01",
    limit: "18 days",
    fine: "0",
  },
  {
    id: 2,
    name: "Atomic Habits",
    author: "James Clear",
    category: "Self Help",
    borrowDate: "2023-08-05",
    limit: "10 days",
    fine: "0",
  },
];

export const BorrowProvider = ({ children }) => {
  const [borrowedBooks, setBorrowedBooks] = useState(initialBorrowedBooks);

  const addBook = (book) => {
    setBorrowedBooks([...borrowedBooks, book]);
  };

  const returnBook = (id) => {
    setBorrowedBooks(borrowedBooks.filter((book) => book.id !== id));
  };

  return (
    <BorrowContext.Provider value={{ borrowedBooks, addBook, returnBook }}>
      {children}
    </BorrowContext.Provider>
  );
};

export const useBorrow = () => useContext(BorrowContext);
